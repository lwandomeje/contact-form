import {
  Actions,
  Store,
  getActionTypeFromInstance,
  getValue,
  ofActionDispatched,
  setValue,
  withNgxsPlugin
} from "./chunk-XHDPMLB3.js";
import {
  FormGroupDirective
} from "./chunk-FPBCXZVC.js";
import "./chunk-5XEBW6XD.js";
import "./chunk-EFM3XAV6.js";
import {
  ChangeDetectorRef,
  Directive,
  Injectable,
  Input,
  NgModule,
  inject,
  setClassMetadata,
  ɵɵdefineDirective,
  ɵɵdefineInjectable,
  ɵɵdefineInjector,
  ɵɵdefineNgModule
} from "./chunk-LFHOIXTK.js";
import {
  ReplaySubject,
  debounceTime,
  distinctUntilChanged,
  filter,
  takeUntil
} from "./chunk-EQS6DRQQ.js";
import "./chunk-HM5YLMWO.js";
import {
  __spreadValues
} from "./chunk-3OV72XIM.js";

// node_modules/@ngxs/form-plugin/fesm2022/ngxs-form-plugin.mjs
var UpdateFormStatus = class {
  static {
    this.type = "[Forms] Update Form Status";
  }
  constructor(payload) {
    this.payload = payload;
  }
};
var UpdateFormValue = class {
  static {
    this.type = "[Forms] Update Form Value";
  }
  constructor(payload) {
    this.payload = payload;
  }
};
var UpdateForm = class {
  static {
    this.type = "[Forms] Update Form";
  }
  constructor(payload) {
    this.payload = payload;
  }
};
var UpdateFormDirty = class {
  static {
    this.type = "[Forms] Update Form Dirty";
  }
  constructor(payload) {
    this.payload = payload;
  }
};
var SetFormDirty = class {
  static {
    this.type = "[Forms] Set Form Dirty";
  }
  constructor(payload) {
    this.payload = payload;
  }
};
var SetFormPristine = class {
  static {
    this.type = "[Forms] Set Form Pristine";
  }
  constructor(payload) {
    this.payload = payload;
  }
};
var UpdateFormErrors = class {
  static {
    this.type = "[Forms] Update Form Errors";
  }
  constructor(payload) {
    this.payload = payload;
  }
};
var SetFormDisabled = class {
  static {
    this.type = "[Forms] Set Form Disabled";
  }
  constructor(payload) {
    this.payload = payload;
  }
};
var SetFormEnabled = class {
  static {
    this.type = "[Forms] Set Form Enabled";
  }
  constructor(payload) {
    this.payload = payload;
  }
};
var ResetForm = class {
  static {
    this.type = "[Forms] Reset Form";
  }
  constructor(payload) {
    this.payload = payload;
  }
};
var NgxsFormPlugin = class _NgxsFormPlugin {
  handle(state, event, next) {
    const type = getActionTypeFromInstance(event);
    let nextState = state;
    if (type === UpdateFormValue.type || type === UpdateForm.type || type === ResetForm.type) {
      const {
        value
      } = event.payload;
      const payloadValue = Array.isArray(value) ? value.slice() : isObjectLike(value) ? __spreadValues({}, value) : value;
      const path = this.joinPathWithPropertyPath(event);
      nextState = setValue(nextState, path, payloadValue);
    }
    if (type === ResetForm.type) {
      const model = getValue(nextState, `${event.payload.path}.model`);
      nextState = setValue(nextState, `${event.payload.path}`, {
        model
      });
    }
    if (type === UpdateFormStatus.type || type === UpdateForm.type) {
      nextState = setValue(nextState, `${event.payload.path}.status`, event.payload.status);
    }
    if (type === UpdateFormErrors.type || type === UpdateForm.type) {
      nextState = setValue(nextState, `${event.payload.path}.errors`, __spreadValues({}, event.payload.errors));
    }
    if (type === UpdateFormDirty.type || type === UpdateForm.type) {
      nextState = setValue(nextState, `${event.payload.path}.dirty`, event.payload.dirty);
    }
    if (type === SetFormDirty.type) {
      nextState = setValue(nextState, `${event.payload}.dirty`, true);
    }
    if (type === SetFormPristine.type) {
      nextState = setValue(nextState, `${event.payload}.dirty`, false);
    }
    if (type === SetFormDisabled.type) {
      nextState = setValue(nextState, `${event.payload}.disabled`, true);
    }
    if (type === SetFormEnabled.type) {
      nextState = setValue(nextState, `${event.payload}.disabled`, false);
    }
    return next(nextState, event);
  }
  joinPathWithPropertyPath({
    payload
  }) {
    let path = `${payload.path}.model`;
    if (payload.propertyPath) {
      path += `.${payload.propertyPath}`;
    }
    return path;
  }
  static {
    this.ɵfac = function NgxsFormPlugin_Factory(__ngFactoryType__) {
      return new (__ngFactoryType__ || _NgxsFormPlugin)();
    };
  }
  static {
    this.ɵprov = ɵɵdefineInjectable({
      token: _NgxsFormPlugin,
      factory: _NgxsFormPlugin.ɵfac
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(NgxsFormPlugin, [{
    type: Injectable
  }], null, null);
})();
function isObjectLike(target) {
  return target !== null && typeof target === "object";
}
var NgxsFormDirective = class _NgxsFormDirective {
  constructor() {
    this.path = null;
    this._debounce = 100;
    this._clearDestroy = false;
    this._updating = false;
    this._actions$ = inject(Actions);
    this._store = inject(Store);
    this._formGroupDirective = inject(FormGroupDirective);
    this._cd = inject(ChangeDetectorRef);
    this._destroy$ = new ReplaySubject(1);
  }
  set debounce(debounce) {
    this._debounce = Number(debounce);
  }
  get debounce() {
    return this._debounce;
  }
  set clearDestroy(val) {
    this._clearDestroy = val != null && `${val}` !== "false";
  }
  get clearDestroy() {
    return this._clearDestroy;
  }
  ngOnInit() {
    this._actions$.pipe(ofActionDispatched(ResetForm), filter((action) => action.payload.path === this.path), takeUntil(this._destroy$)).subscribe(({
      payload: {
        value
      }
    }) => {
      this.form.reset(value);
      this.updateFormStateWithRawValue(true);
      this._cd.markForCheck();
    });
    this.getStateStream(`${this.path}.model`).subscribe((model) => {
      if (this._updating || !model) {
        return;
      }
      this.form.patchValue(model);
      this._cd.markForCheck();
    });
    this.getStateStream(`${this.path}.dirty`).subscribe((dirty) => {
      if (this.form.dirty === dirty || typeof dirty !== "boolean") {
        return;
      }
      if (dirty) {
        this.form.markAsDirty();
      } else {
        this.form.markAsPristine();
      }
      this._cd.markForCheck();
    });
    this._store.selectOnce((state) => getValue(state, this.path)).subscribe(() => {
      this._store.dispatch([new UpdateFormValue({
        path: this.path,
        value: this.form.getRawValue()
      }), new UpdateFormStatus({
        path: this.path,
        status: this.form.status
      }), new UpdateFormDirty({
        path: this.path,
        dirty: this.form.dirty
      })]);
    });
    this.getStateStream(`${this.path}.disabled`).subscribe((disabled) => {
      if (this.form.disabled === disabled || typeof disabled !== "boolean") {
        return;
      }
      if (disabled) {
        this.form.disable();
      } else {
        this.form.enable();
      }
      this._cd.markForCheck();
    });
    this._formGroupDirective.valueChanges.pipe(distinctUntilChanged((a, b) => JSON.stringify(a) === JSON.stringify(b)), this.debounceChange()).subscribe(() => {
      this.updateFormStateWithRawValue();
    });
    this._formGroupDirective.statusChanges.pipe(distinctUntilChanged(), this.debounceChange()).subscribe((status) => {
      this._store.dispatch(new UpdateFormStatus({
        status,
        path: this.path
      }));
    });
  }
  updateFormStateWithRawValue(withFormStatus) {
    if (this._updating) return;
    const value = this._formGroupDirective.control.getRawValue();
    const actions = [new UpdateFormValue({
      path: this.path,
      value
    }), new UpdateFormDirty({
      path: this.path,
      dirty: this._formGroupDirective.dirty
    }), new UpdateFormErrors({
      path: this.path,
      errors: this._formGroupDirective.errors
    })];
    if (withFormStatus) {
      actions.push(new UpdateFormStatus({
        path: this.path,
        status: this._formGroupDirective.status
      }));
    }
    this._updating = true;
    this._store.dispatch(actions).subscribe({
      error: () => this._updating = false,
      complete: () => this._updating = false
    });
  }
  ngOnDestroy() {
    this._destroy$.next();
    if (this.clearDestroy) {
      this._store.dispatch(new UpdateForm({
        path: this.path,
        value: null,
        dirty: null,
        status: null,
        errors: null
      }));
    }
  }
  debounceChange() {
    const skipDebounceTime = this._formGroupDirective.control.updateOn !== "change" || this._debounce < 0;
    return skipDebounceTime ? (change) => change.pipe(takeUntil(this._destroy$)) : (change) => change.pipe(debounceTime(this._debounce), takeUntil(this._destroy$));
  }
  get form() {
    return this._formGroupDirective.form;
  }
  getStateStream(path) {
    return this._store.select((state) => getValue(state, path)).pipe(takeUntil(this._destroy$));
  }
  static {
    this.ɵfac = function NgxsFormDirective_Factory(__ngFactoryType__) {
      return new (__ngFactoryType__ || _NgxsFormDirective)();
    };
  }
  static {
    this.ɵdir = ɵɵdefineDirective({
      type: _NgxsFormDirective,
      selectors: [["", "ngxsForm", ""]],
      inputs: {
        path: [0, "ngxsForm", "path"],
        debounce: [0, "ngxsFormDebounce", "debounce"],
        clearDestroy: [0, "ngxsFormClearOnDestroy", "clearDestroy"]
      }
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(NgxsFormDirective, [{
    type: Directive,
    args: [{
      selector: "[ngxsForm]",
      standalone: true
    }]
  }], null, {
    path: [{
      type: Input,
      args: ["ngxsForm"]
    }],
    debounce: [{
      type: Input,
      args: ["ngxsFormDebounce"]
    }],
    clearDestroy: [{
      type: Input,
      args: ["ngxsFormClearOnDestroy"]
    }]
  });
})();
var NgxsFormPluginModule = class _NgxsFormPluginModule {
  static forRoot() {
    return {
      ngModule: _NgxsFormPluginModule,
      providers: [withNgxsPlugin(NgxsFormPlugin)]
    };
  }
  static {
    this.ɵfac = function NgxsFormPluginModule_Factory(__ngFactoryType__) {
      return new (__ngFactoryType__ || _NgxsFormPluginModule)();
    };
  }
  static {
    this.ɵmod = ɵɵdefineNgModule({
      type: _NgxsFormPluginModule,
      imports: [NgxsFormDirective],
      exports: [NgxsFormDirective]
    });
  }
  static {
    this.ɵinj = ɵɵdefineInjector({});
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(NgxsFormPluginModule, [{
    type: NgModule,
    args: [{
      imports: [NgxsFormDirective],
      exports: [NgxsFormDirective]
    }]
  }], null, null);
})();
function withNgxsFormPlugin() {
  return withNgxsPlugin(NgxsFormPlugin);
}
export {
  NgxsFormDirective,
  NgxsFormPlugin,
  NgxsFormPluginModule,
  ResetForm,
  SetFormDirty,
  SetFormDisabled,
  SetFormEnabled,
  SetFormPristine,
  UpdateForm,
  UpdateFormDirty,
  UpdateFormErrors,
  UpdateFormStatus,
  UpdateFormValue,
  withNgxsFormPlugin
};
//# sourceMappingURL=@ngxs_form-plugin.js.map
