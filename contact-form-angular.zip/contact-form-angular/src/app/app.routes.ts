import { Routes } from '@angular/router';
import { LoginGuard } from './guards/log-in.guard';
import { AuthGuard } from './guards/auth.guard';
import { CheckOutGuard } from './guards/check-out.guard';
import { PaymentResultGuard } from './guards/payment-results.guard';
import { ForgotPasswordGuard } from './guards/forgot-password.guard';
import { VerifyOtpGuard } from './guards/verify-otp.guard';

export const routes: Routes = [
    {
        path: '',
        pathMatch: 'full',
        loadComponent: () => import('./pages/login/login.component').then(m => m.LoginComponent),
        canActivate: [LoginGuard]
    },
    {
        path: 'register',
        loadComponent: () => import('./pages/register/register.component').then(m => m.RegisterComponent),
    },
    {
        path: 'forgot-password',
        loadComponent: () => import('./pages/forgot-password/forgot-password.component').then(m => m.ForgotPasswordComponent),
    },
    {
        path: 'verify-opt',
        loadComponent: () => import('./pages/verity-otp/verity-otp.component').then(m => m.VerityOtpComponent),
        canActivate: [VerifyOtpGuard]
    },
    {
        path: 'reset-password',
        loadComponent: () => import('./pages/reset-password/reset-password.component').then(m => m.ResetPasswordComponent),
        canActivate: [ForgotPasswordGuard]
    },
    {
        path: 'landing',
        loadComponent: () => import('./pages/landing/landing.component').then(m => m.LandingComponent),
        canActivate: [AuthGuard]
    },
    {
        path: 'products',
        loadComponent: () => import('./pages/products/products.component').then(m => m.ProductsComponent),
        canActivate: [AuthGuard]
    },
    {
        path: 'check-out',
        loadComponent: () => import('./pages/check-out/check-out.component').then(m => m.CheckOutComponent),
        canActivate: [AuthGuard, CheckOutGuard]
    },
    {
        path: 'last-check-out',
        loadComponent: () => import('./components/last-check-out/last-check-out.component').then(m => m.LastCheckOutComponent),
        canActivate: [AuthGuard]
    },
    {
        path: 'payment-result',
        loadComponent: () => import('./pages/payment-result/payment-result.component').then(m => m.PaymentResultComponent),
        canActivate: [
            AuthGuard,
            CheckOutGuard,
            PaymentResultGuard
        ]
    },
    {
        path: 'contact',
        loadComponent: () => import('./pages/contact-form/contact-form.component').then(m => m.ContactFormComponent),
    },
    {
        path: '**', redirectTo: "/", pathMatch: 'full'
    }
];
