export interface Dessert {
    image: {
      thumbnail: string;
      mobile: string;
      tablet: string;
      desktop: string;
    };
    name: string;
    category: string;
    price: number;
    productId: string,
    quantity?: number;
    isInCart?:boolean
  }
  