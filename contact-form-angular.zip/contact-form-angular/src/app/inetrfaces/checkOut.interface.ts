import { Dessert } from "./desserts.interface";
import { DeliveryAddress } from "../store/deliveryAddress";
import { PeachCardToken } from "./peachCardToken.interface";


export interface CheckOut {
    checkOutId: string,
    date: string,
    cart: Dessert[],
    address: DeliveryAddress,
    payment: PeachCardToken,
    checkOutTota: number,
}