export interface NominatimResult {
  lat: string;           // Latitude of the place
  lon: string;          // Longitude of the place
  display_name: string; // Full address name
}