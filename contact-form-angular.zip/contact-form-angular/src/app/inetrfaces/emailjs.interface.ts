import { Dessert } from "./desserts.interface"

export interface emailRequest{
    checkOutId: string,
    date: string,
    locationName: string,
    cart: Dessert[],
    brand: string,
    last4: string,
    expiryMonth: string,
    expiryYear: string,
    checkOutTotal: number
}