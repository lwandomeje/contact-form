export interface PeachCardToken{
    token: string;       
    brand: string;       
    last4: string;       
    expiryMonth: string; 
    expiryYear: string;
    isCardSaved?: boolean
}

export interface PeachCard {
    cardHolder: string;
    cardNumber: string;
    expiryMonth: string;
    expiryYear: string;
    cvv: string
}