import { Injectable, } from "@angular/core";
import { CanActivate, Router  } from "@angular/router";
import { Store } from "@ngxs/store";
import { AuthState } from "../store/auth/auth.state";
import { Subject, takeUntil } from "rxjs";



@Injectable({providedIn:'root'})

export class ForgotPasswordGuard implements CanActivate{
    private destroy$ = new Subject<void>()
    constructor(
        private store : Store,
        private router : Router
    ){}


    canActivate(): boolean {
        let isVerified = false
        const isVerified$ = this.store.select(AuthState.getOPTVerified)
        isVerified$
        .pipe( 
            takeUntil((this.destroy$))
        )
        .subscribe(
            ( res: boolean) => isVerified = res
        )
        if (!isVerified) {
            this.router.navigateByUrl('/verify-opt')
            return false
        }
        return true
    }




}