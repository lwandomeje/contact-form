import { Injectable} from "@angular/core";
import { CanActivate, Router } from "@angular/router";
import { Store } from "@ngxs/store";
import { CartState } from "../store/cart/cart.state";


@Injectable({providedIn: 'root'})

export class CheckOutGuard implements CanActivate {

    constructor(
        private store : Store,
        private router: Router
        
    ){}

    canActivate(): boolean {
       const isConfirmed = this.store.selectSnapshot( CartState.getIsConfirmed);
       const cartItems = this.store.selectSnapshot(CartState.getAllCartItems)
       if(!isConfirmed || cartItems.length <= 0){
        this.router.navigateByUrl('/products')
        return false
       }
       return true
    }
}