import { Injectable, inject } from "@angular/core";
import { CanActivate, Router } from "@angular/router";
import { Store } from "@ngxs/store";
import { AuthState } from "../store/auth/auth.state";

@Injectable({providedIn: 'root'})

export class AuthGuard implements CanActivate {

  private store = inject(Store);
  private router = inject(Router); 
  
  canActivate(): boolean{
    const isAuthenticated = this.store.selectSnapshot( AuthState.getIsAuth);
     if(!isAuthenticated){
        this.router.navigateByUrl('')
        return false
    }
    return true
  }

}