import { Injectable, OnDestroy } from "@angular/core";
import { CanActivate, Router  } from "@angular/router";
import { Store } from "@ngxs/store";
import { AuthState } from "../store/auth/auth.state";
import { Subject, takeUntil } from "rxjs";


@Injectable({providedIn:'root'})

export class VerifyOtpGuard implements CanActivate, OnDestroy{

    private destroy$ = new Subject<void>()

    constructor(
        private store : Store,
        private router : Router
    ){}

    canActivate(): boolean{
        let isOtpSent = false
        const isOtpSent$ = this.store.select(AuthState.getIsOTPSent)
        isOtpSent$
        .pipe( 
            takeUntil((this.destroy$))
        )
        .subscribe(
            ( res: boolean) => isOtpSent = res
        )
        if (!isOtpSent) {
            this.router.navigateByUrl('/forgot-password')            
            return false
        }
        return true
    }

    ngOnDestroy(): void {
        this.destroy$.next();
        this.destroy$.complete()
    }

}

