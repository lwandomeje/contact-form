import { Injectable } from "@angular/core";
import { CanActivate, Router  } from "@angular/router";
import { Store } from "@ngxs/store";
import { CheckOutState } from "../store/checkOut/checkOut.state";


@Injectable({providedIn:'root'})

export class PaymentResultGuard implements CanActivate{

    constructor(
        private store : Store,
        private router : Router
    ){}

    canActivate(): boolean{
        const ispayed = this.store.selectSnapshot( CheckOutState.getIsPayed)
        if(!ispayed){
            this.router.navigateByUrl('/check-out')
            return false
        }
        return true
    }

}