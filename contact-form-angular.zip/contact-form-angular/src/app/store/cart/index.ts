import { Dessert } from "../../inetrfaces/desserts.interface";

export interface CartStateModel {
    isconfirmed: boolean
    CartItems: Dessert[]
}