import { Dessert } from "../../inetrfaces/desserts.interface";

export class AddDessertToCart {
    static readonly type = '[cart] load dessert to cart, and change isInCart:true and quantity:1'
    constructor(public dessert:Dessert){}
}

export class updateDessert{
    static readonly type = '[cart] update is isIncart state true and update quantity'
    constructor(public payload: {productId: string; isInCart:boolean; quantity: number}){}
}

export class RemoveDessertFomCart {
    static readonly type = '[cart] remove a dessert fom the cart '
    constructor(public dessert: Dessert){}
}

export class ConfirmCart {
    static readonly type = '[cart] comfirm cart'
    constructor(public confirm: boolean){}
}

export class resetCartState {
    static readonly type = '[cart] reset state'
    
}

