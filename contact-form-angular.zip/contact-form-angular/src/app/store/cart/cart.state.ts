import { Injectable } from "@angular/core";
import { CartStateModel } from ".";
import { State, Action, Selector, StateContext } from "@ngxs/store";
import * as CartActions from './cart.actions'


const initialState: CartStateModel = {
    isconfirmed: false,
    CartItems : []
}

@State<CartStateModel>({
    name:'CartState',
    defaults: initialState
})


@Injectable()
export class CartState {

    @Selector()
    static getIsConfirmed(state: CartStateModel){
        return state.isconfirmed
    }

    @Selector()
    static getAllCartItems(state:CartStateModel){
        return state.CartItems
    }

    @Selector()
    static isInCart(state:CartStateModel){
        return (productId: string) => {
            const dessert = state.CartItems.find( d => d.productId === productId);// returns create an single object {}
            return !! dessert?.isInCart 
        }
    }

    @Selector()
    static dessertCount(state:CartStateModel){
        return (productId: string) => {
            const dessert = state.CartItems.find(d => d.productId === productId);
            return dessert?.quantity || 0
        }
    }
    
    @Selector()
    static getTotalCartPrice(state:CartStateModel){
        return state.CartItems.reduce((total, item) =>{
            const quantity = item.quantity ?? 1;
            return total + item.price * quantity
        },0)
    }

    @Selector()
    static getSingleTotal(state:CartStateModel){
        return (productId: string) => {
            const dessert = state.CartItems.find(d => d.productId === productId)
            if (!dessert) return 0;
            const total = dessert.price * (dessert.quantity ?? 1)
            return total
        }
    }

    @Selector()
    static getNumberOfCartItems(state:CartStateModel){
        return state.CartItems
        .map(dessert => dessert.quantity ?? 0)
        .reduce((total, item) => total + item,0)
    }

    @Action(CartActions.AddDessertToCart)
    AddDesserts(ctx: StateContext<CartStateModel>, action: CartActions.AddDessertToCart){
        const state = ctx.getState()
        if(!state.CartItems.some(d => d.productId === action.dessert.productId)){
            const updatedCart = [...state.CartItems, { ...action.dessert }]
           ctx.patchState({
            CartItems: updatedCart
           });
        }   
    }
    
    @Action(CartActions.updateDessert)
    updateDessert(ctx: StateContext<CartStateModel>, action: CartActions.updateDessert){
        const state = ctx.getState()
        const upDatedDessert = state.CartItems.map(item => item.productId === action.payload.productId
            ? {...item, isInCart: action.payload.isInCart , quantity: action.payload.quantity}: item
        )
        ctx.patchState({
            CartItems: upDatedDessert
        })
    }

    @Action(CartActions.RemoveDessertFomCart)
    removeDessert(ctx: StateContext<CartStateModel>, action: CartActions.RemoveDessertFomCart){ 
        const state = ctx.getState()
        const updatedCart = state.CartItems.filter( d => d.productId !== action.dessert.productId)
        ctx.patchState({
            CartItems: updatedCart
        });

    }

    @Action(CartActions.resetCartState)
    reSet(ctx: StateContext<CartStateModel>){
        ctx.setState(initialState)
    }

    @Action(CartActions.ConfirmCart)
    ConfirmCart(ctx: StateContext<CartStateModel>, action: CartActions.ConfirmCart){
        ctx.patchState({
            isconfirmed: action.confirm
        })
    }


}

