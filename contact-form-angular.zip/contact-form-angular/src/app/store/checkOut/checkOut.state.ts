import { Injectable } from "@angular/core";
import { CheckOutStateModel } from ".";
import { loadlastCheckOut, PayCheckOut, reSetCheckOut, setCheckOut } from "./checkOut.actions";
import { Action, Selector, State, StateContext } from "@ngxs/store";
import { CheckOut } from "../../inetrfaces/checkOut.interface";
import { AuthServiceService } from "../../services/auth-service.service";

const initialState: CheckOutStateModel = {
    ispayed: false,
    checkOut: {
        checkOutId: '',
        date: '',
        cart: [],
        address: {
            locationName : '',
            haveLocation: false,
        },
        payment: {
            token: '',       
            brand: '',      
            last4: '',      
            expiryMonth: '',
            expiryYear: '',
            isCardSaved: false 
        },
        checkOutTota: 0,
    }
}

@State<CheckOutStateModel>({
    name :'CheckOutState',
    defaults: initialState
})

@Injectable()

export class CheckOutState {

    last_check_out_key = 'lastCheckOut';

    constructor(
        private authService: AuthServiceService
    ){}

    private getUserLastCheckOut(userID:string){
        const allCheckOuts = JSON.parse(localStorage.getItem(this.last_check_out_key)|| '{}')
        return allCheckOuts[userID] || {}
    }

    private saveUserCheckOut(userID:string, checkOut: CheckOut) {
        const allCheckOuts = JSON.parse(localStorage.getItem(this.last_check_out_key) || '{}')
        allCheckOuts[userID] = checkOut
        localStorage.setItem(this.last_check_out_key, JSON.stringify(allCheckOuts))
    }

    @Selector()
    static getIsPayed(state: CheckOutStateModel){
        return state.ispayed
    }

    @Selector()
    static getCheckOut(state:CheckOutStateModel){
        return state.checkOut
    }

    @Action(setCheckOut)
    setCheckOut(ctx: StateContext<CheckOutStateModel>, action:setCheckOut){
        const loggedInUser = JSON.parse(sessionStorage.getItem(this.authService.LOGGED_IN_KEY) || '{}')
        const userId = loggedInUser.userID
        this.saveUserCheckOut(userId, action.payload)
        ctx.patchState({
            checkOut: action.payload
        })
    }

    @Action(loadlastCheckOut)
    loadlastCheckOut(ctx: StateContext<CheckOutStateModel>){
        const loggedInUser = JSON.parse(sessionStorage.getItem(this.authService.LOGGED_IN_KEY) || '{}')
        const userid = loggedInUser.userID
        const checkOut = this.getUserLastCheckOut(userid)
        ctx.patchState({
            checkOut: checkOut
        })
    }

    @Action(reSetCheckOut)
    reSetCheckOut(ctx: StateContext<CheckOutStateModel>){
        ctx.setState(initialState)
    }

    @Action(PayCheckOut)
    PayCheckOut(ctx: StateContext<CheckOutStateModel>, action: PayCheckOut){
       ctx.patchState({
            ispayed: action.payed
       })
    }



}
