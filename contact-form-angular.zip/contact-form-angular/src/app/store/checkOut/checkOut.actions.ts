import { CheckOut } from "../../inetrfaces/checkOut.interface";

export class setCheckOut {
    static readonly type = '[check Out] create a check out object '
    constructor(public payload: CheckOut){}
}
export class reSetCheckOut {
    static readonly type = '[check out] reset checkOut state'
}

export class loadlastCheckOut {
    static readonly type = '[check out] load user last check out info'
}

export class PayCheckOut {
    static readonly type = '[check out] pay for the order'
    constructor(public payed: boolean){}
}