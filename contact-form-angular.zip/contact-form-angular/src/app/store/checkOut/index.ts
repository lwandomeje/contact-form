import { CheckOut } from "../../inetrfaces/checkOut.interface";

export interface CheckOutStateModel {
    ispayed: boolean,
    checkOut: CheckOut
}