export class Register {
  static readonly type = '[Auth] Register';
  constructor(public email: string, public password: string) {}
}

export class Login {
  static readonly type = '[Auth] Login';
  constructor(public email: string, public password: string) {}
}

export class Logout {
  static readonly type = '[Auth] Logout';
}

export class SendOtp {
  static readonly type = '[Auth] Send OTP';
  constructor(public email: string) {}
}


export class VerifyOtp  {
  static readonly type = '[Auth] Verify OTP entered by the user';
  constructor(public email: string, public otp: string) {}
}

export class IsOTPVerified {
  static readonly type = '[Auth] is otp verified';
}

export class IsOTPSent {
  static readonly type = '[Auth] is otp sent to the user';
}

export class ResetPassword {
  static readonly type = '[Auth] Reset Password';
  constructor(public email: string, public newPassword: string) {}
}
