export interface AuthStateModel {
    isOTPSent: boolean;
    otpVerified: boolean;
    user: string | null;   
    loading: boolean;
    isAuthenticated: boolean;
    error: string | null;
}