import { Injectable} from "@angular/core";
import { AuthStateModel} from ".";
import * as authActions from './auth.actions'
import { AuthServiceService } from "../../services/auth-service.service";
import { Action, Selector, State, StateContext } from "@ngxs/store";
import { catchError, of, tap, } from "rxjs";
import { resetCartState } from "../cart/cart.actions";
import { Store } from "@ngxs/store";
import { changeUserLocation, loadUsersLocation } from "../deliveryAddress/delivery.actions";
import { loadUserCard, resetCardDetails } from "../cardPayment/cardPayment.actions";
import { loadlastCheckOut, reSetCheckOut,} from "../checkOut/checkOut.actions";

// State should only keep current session + status.

@State<AuthStateModel>({
    name: 'AuthState',
    defaults: {
        isOTPSent: false,
        otpVerified: false,
        user: null, 
        isAuthenticated: false,
        loading: false,
        error: null,
    },
})

@Injectable()

export class AuthState {

    constructor(
        private store : Store, 
        private authService: AuthServiceService,
    ) {}


    @Selector()
    static getIsOTPSent(state: AuthStateModel){
        return state.isOTPSent
    }

    @Selector()
    static getOPTVerified(state: AuthStateModel){
        return state.otpVerified
    }

    @Selector()
    static getIsAuth(state : AuthStateModel){
        return state.isAuthenticated
    }

    @Selector()
    static getErrorMessage(state : AuthStateModel){
        return state.error
    }

    @Action(authActions.Register)
    Register(ctx: StateContext<AuthStateModel>, action: authActions.Register){
        ctx.patchState({loading:true, error: null});
        return this.authService.register(action.email, action.password)
        .pipe(
            tap(() => {
                ctx.patchState({
                    loading: false
                })
            }),
            catchError((err) => {
                ctx.patchState({loading:false, error: err.message})
                return of(err)
            })
        )
    }

    @Action(authActions.Login)
    Login(ctx:  StateContext<AuthStateModel>, action: authActions.Login){
       ctx.patchState({loading:true, error: null});       
       return this.authService.login(action.email, action.password)
       .pipe(
            tap(() =>{
                ctx.patchState({
                    user: action.email,
                    isAuthenticated:true,
                    loading: false,
                    error: null,
                });

                const loggedIn = JSON.parse(sessionStorage.getItem(this.authService.LOGGED_IN_KEY) || '{}')
                this.store.dispatch(new loadUsersLocation(loggedIn.userID))
                this.store.dispatch( new loadUserCard())
                this.store.dispatch( new loadlastCheckOut())
            }),

            
            catchError((err) => {
                ctx.patchState({loading:false, error: err.message})
                return of(err)
            })
       )
    }

    @Action(authActions.Logout)
    logout(ctx: StateContext<AuthStateModel>) {
        this.store.dispatch( new resetCartState())
        this.store.dispatch( new resetCardDetails())
        this.store.dispatch( new changeUserLocation())
        this.store.dispatch( new reSetCheckOut())
        this.authService.logout();
        ctx.setState({
            isOTPSent: false,
            otpVerified: false,
            user: null,
            isAuthenticated: false,
            loading: false,
            error: null,
        });
    }

    @Action(authActions.SendOtp)
    SendOtp(ctx:StateContext<AuthStateModel> , action: authActions.SendOtp){
        ctx.patchState({loading:true, error:null})
        return this.authService.sendPasswordResetOtp(action.email)
        .pipe(
            tap(() =>{
                ctx.patchState({
                    loading: false
                })
            }),
            catchError((err) => {
                ctx.patchState({
                    isOTPSent: true, 
                    loading: false, 
                    error: err.message
                });
                return of(err);
            })
        )
    }

    @Action(authActions.IsOTPSent)
    IsOTPSent(ctx:StateContext<AuthStateModel>){
        ctx.patchState({
            isOTPSent: false
        })
    }

    @Action(authActions.VerifyOtp)
    VerifyOtp(ctx: StateContext<AuthStateModel>, action:authActions.VerifyOtp){
        ctx.patchState({loading:true , error: null})
        return this.authService.verifyOTP(action.email, action.otp)
        .pipe(
            tap(() =>{
                ctx.patchState({
                    otpVerified: true,
                    loading:false
                })
            }),
            catchError((err) => {
                ctx.patchState({loading: false, error: err.message})
                return of(err)
            })
        )
    }

    @Action(authActions.IsOTPVerified)
    IsOTPVerified(ctx: StateContext<AuthStateModel>){
        ctx.patchState({
           otpVerified: false 
        })
    }

    @Action(authActions.ResetPassword)
    ResetPassword(ctx: StateContext<AuthStateModel> , action: authActions.ResetPassword){
        ctx.patchState({loading:true , error: null})
        return this.authService.resetPassword(action.email, action.newPassword)
        .pipe(
            tap(() => {
                ctx.patchState({
                    otpVerified: false,
                    loading: false 
                });
            }),
            catchError((err) => {
                ctx.patchState({ loading: false, error: err.message });
                return of(err);
            })
        );
    }


}


