import { PeachCard } from "../../inetrfaces/peachCardToken.interface";

export class addCardDetails {
    static readonly type = ' [cardPayment] add card details '
    constructor(public payload: PeachCard){}
}

export class resetCardDetails {
    static readonly type = ' [cardPayment] resetState'
}

export class loadUserCard{
    static readonly type ='[cardPayment] load the user saved card to the state'
}