import { Injectable } from "@angular/core";
import { PeachCardToken } from "../../inetrfaces/peachCardToken.interface";
import { State, Action, StateContext, Selector } from "@ngxs/store";
import { addCardDetails, loadUserCard, resetCardDetails } from "./cardPayment.actions";
import { PeachPaymentService } from "../../services/peach-payment.service";
import { catchError, of, tap } from "rxjs";
import { AuthServiceService } from "../../services/auth-service.service";


export interface CardPaymentStateModel {
    peachCardToken : PeachCardToken
}

const initialState: CardPaymentStateModel = {
    peachCardToken: {
        token: '',
        brand: '',
        last4: '',
        expiryMonth: '',
        expiryYear: '',
        isCardSaved: false
    }
}

@State<CardPaymentStateModel> ({
    name: 'CardPaymentState',
    defaults:  initialState 
})

@Injectable()

export class CardPaymentState {
    
    
    CARDS_KEY = 'users_cards' // all users cards will be stored in this localSorage table

    

    constructor(
        private peachPaymentService: PeachPaymentService,
        private authService : AuthServiceService
    ){}

    private getUserCard(userID: string){
        const allCards = JSON.parse(localStorage.getItem(this.CARDS_KEY) || '{}')
        return allCards[userID] || {}
    }

    private saveUserCard(userID: string, card: PeachCardToken){
        const allCards = JSON.parse(localStorage.getItem(this.CARDS_KEY) || '{}')
        allCards[userID] = card
        localStorage.setItem(this.CARDS_KEY, JSON.stringify(allCards))
    }



    @Selector()
    static getpeachCardToken(state:CardPaymentStateModel){
        return state.peachCardToken
    }

    @Action(addCardDetails)
    addCardDetails(ctx: StateContext<CardPaymentStateModel>, action: addCardDetails){
        const loggedInUser = JSON.parse(sessionStorage.getItem(this.authService.LOGGED_IN_KEY)|| '{}' )
        const userID = loggedInUser.userID
        return this.peachPaymentService.createToken(action.payload).pipe(
           tap((res: PeachCardToken) => {
                if(res){
                    const body: PeachCardToken = {
                        token: res.token,
                        brand: res.brand,
                        last4: res.last4,
                        expiryMonth: res.expiryMonth,
                        expiryYear: res.expiryYear,
                        isCardSaved: true,
                    }
                    this.saveUserCard(userID, body)
                    const savedCard = this.getUserCard(userID)
                    ctx.patchState({peachCardToken: savedCard})
                }
           }),
           catchError(() => {
                return of()
           })
        )
    }

    @Action(loadUserCard)
    loadUserCard(ctx: StateContext<CardPaymentStateModel>){
        const loggedInUser = JSON.parse(sessionStorage.getItem(this.authService.LOGGED_IN_KEY)|| '{}' )
        const userID = loggedInUser.userID
        const card = this.getUserCard(userID)
        ctx.patchState({
            peachCardToken: card
        })

    }

    @Action(resetCardDetails)
    reset(ctx: StateContext<CardPaymentStateModel>){
        ctx.setState(initialState)
    }

    

}