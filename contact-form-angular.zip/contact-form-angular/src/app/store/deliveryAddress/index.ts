export interface DeliveryAddress {
    locationName : string,
    haveLocation: boolean
}

export interface DeliveryAddressStateModel{
    userID: string,
    deviveryAddress: DeliveryAddress
}