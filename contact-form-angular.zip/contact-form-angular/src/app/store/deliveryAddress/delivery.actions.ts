import { DeliveryAddress } from "."

export class setDeliveryLocation {
    static readonly type = '[Delivery location] set the location of the delivery'
    constructor(public payload: DeliveryAddress){}
}

export class loadUsersLocation {
    static readonly type = "[Delivery location] load user's location "
    constructor(public userID: string){}
}

export class saveLocation {
    static readonly type = " [Delivery location] save delivery location in local store"
    constructor (public locationName: string){}
}

export class changeUserLocation {
    static readonly type = "[Delivery location] reset user location"
}