import { Injectable } from "@angular/core";
import { State, StateContext } from "@ngxs/store";
import { Action, Selector } from "@ngxs/store";
import { DeliveryAddressStateModel} from '.'
import { changeUserLocation, loadUsersLocation , saveLocation} from "./delivery.actions";
import { AuthServiceService } from "../../services/auth-service.service";


@State<DeliveryAddressStateModel>({
    name:'DeliveryAddressState',
    defaults: {
        userID: '',
        deviveryAddress: {
            locationName: '',
            haveLocation: false
        }
    }
})

@Injectable()

export class DeliveryAddressState{

    

    constructor(
        private authservice: AuthServiceService
    ){}

    // fake table that stores all the delivery addresses 
    private readonly LOCATION_KEY = 'users_location'

    // helpers  mimicing a backend, but using localstorage  
    // get all the delivery addresses form my users_location database and then look up for the on I want using userID 
    // if found returns the user's address, 
    // if not return an empty object 
    private getUserLocation(userID:string){
        const allLocation = JSON.parse(localStorage.getItem(this.LOCATION_KEY) || '{}')
        return allLocation[userID] || {}
    }


    // You first "fetch" (getUserLocation) to make sure you’re updating the right data.
    // If that user already had an address → replace it.
    // If not → create a new address entry for them.
    // Finally, you persist the updated "database" back into localStorage.
    private saveUserLocation (userID: string, delivery: string){
       const allLocation = JSON.parse(localStorage.getItem(this.LOCATION_KEY) || '{}')
       allLocation[userID] = {locationName : delivery}
       localStorage.setItem(this.LOCATION_KEY, JSON.stringify(allLocation))

    }

    @Selector()
    static getdeviveryAddress(state:DeliveryAddressStateModel){
        return state.deviveryAddress
    }



    @Action(saveLocation)
    saveLocation(ctx: StateContext<DeliveryAddressStateModel>, action: saveLocation){
        const loggedInUser = JSON.parse(sessionStorage.getItem(this.authservice.LOGGED_IN_KEY) || '{}')
        if (loggedInUser.userID) {
            this.saveUserLocation(loggedInUser.userID, action.locationName)
            const allUsersLocation = this.getUserLocation(loggedInUser.userID)
            const payload = {locationName: allUsersLocation.locationName , haveLocation: true }
            ctx.patchState({
                userID: loggedInUser.userID,
                deviveryAddress: payload
            })
        }
    }

    @Action(loadUsersLocation)
    loadUsersLocation(ctx: StateContext<DeliveryAddressStateModel>, action: loadUsersLocation){
        const location = this.getUserLocation(action.userID)
        let haveLocation = false
        if (location.locationName) {
            haveLocation = true
        }
        const payload = {locationName: location.locationName, haveLocation: haveLocation}
        
        ctx.patchState({
            userID: action.userID, 
            deviveryAddress: payload})
    }

    @Action(changeUserLocation)
    changeUserLocation(ctx: StateContext<DeliveryAddressStateModel>){
        ctx.patchState({
            userID: '',
            deviveryAddress:{
            locationName: '',
            haveLocation: false
        }
        })
    }
}
