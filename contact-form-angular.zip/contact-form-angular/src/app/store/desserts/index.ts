export interface Dessert {
    image: {
      thumbnail: string;
      mobile: string;
      tablet: string;
      desktop: string;
    };
    name: string;
    category: string;
    price: number;
    productId: string;
    isInCart?:boolean ;
    quantity?: number;
  }

  export interface DessertsStateModel{
    desserts: Dessert[]
  }