import { Injectable } from "@angular/core";
import { State, StateContext } from "@ngxs/store";
import { Action, Selector} from "@ngxs/store";
import { Dessert , DessertsStateModel} from '.'
import { DessertsService } from "../../services/desserts.service";
import * as dessertsAction from "./desserts.action"
import { catchError, of, tap } from "rxjs";

@State<DessertsStateModel>({
    name:'DessertsState',
    defaults: {
        desserts: []
    }
})

@Injectable()

export class DessertsState {
//   ngxsOnInit(ctx: StateContext<DessertsStateModel>){
//     console.log('State initialized with:', ctx.getState());
//   }
    
    constructor( private dessertsService : DessertsService){}

    @Selector()
    static getAllDesserts(state:DessertsStateModel){
        return state.desserts
    }
    @Selector()
    static getCakesCategory(state:DessertsStateModel){
        return state.desserts.filter(d => d.category === "Cake")
    }

    @Selector()
    static getWafflesCategory(state:DessertsStateModel){
        return state.desserts.filter(d => d.category === "Waffle")
    }

    @Selector()
    static getPieCategory(state:DessertsStateModel){
        return state.desserts.filter(d => d.category === 'Pie')
    }

    @Selector()
    static getBrownieCategory(state:DessertsStateModel){
        return state.desserts.filter(d => d.category === "Brownie")
    }
    
    @Action(dessertsAction.getDesserts)
    getDesserts(ctx: StateContext<DessertsStateModel>){
        return this.dessertsService.getDesserts().pipe(
            tap((res: Dessert[]) => {
                if(res){
                    ctx.patchState({desserts : res})
                }
            }),
            catchError(() => {
                return of()
            })
        )
    }

}



