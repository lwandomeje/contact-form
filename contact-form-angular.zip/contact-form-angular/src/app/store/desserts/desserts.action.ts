
export class getDesserts {
    static readonly type = '[dessert] load desserts'
}

