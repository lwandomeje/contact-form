import { Component, inject} from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { NavbarComponent } from './components/navbar/navbar.component';
import { MatSlideToggleModule} from '@angular/material/slide-toggle';
import { FormsModule } from '@angular/forms';
import { Store } from '@ngxs/store';
import { Logout } from './store/auth/auth.actions';
import { Router } from '@angular/router';
import { AuthState } from './store/auth/auth.state';

@Component({
  selector: 'app-root',
  imports: [
    RouterModule,
    NavbarComponent,
    MatSlideToggleModule,
    FormsModule,
    CommonModule
  ],
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss'
})
export class AppComponent {

  private store = inject(Store)
  title = 'Sugar Bloom';
  isDark = false;
  isAuth$ = this.store.select( AuthState.getIsAuth)

  constructor(
    private readonly route : Router,
  ){}



  toggleDarkMode(){
    if(this.isDark){
      document.body.classList.add('dark-mode')
    }else{
      document.body.classList.remove('dark-mode')
    }    
  }

  logOut(){
    this.store.dispatch( new Logout())
    this.route.navigateByUrl('',{ replaceUrl: true })
  }

}
