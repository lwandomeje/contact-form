import { provideHttpClient, withFetch } from '@angular/common/http';
import { ApplicationConfig, provideZoneChangeDetection } from '@angular/core';
import { provideRouter } from '@angular/router';
import { routes } from './app.routes';
import { provideClientHydration, withEventReplay } from '@angular/platform-browser';
import { withNgxsReduxDevtoolsPlugin } from '@ngxs/devtools-plugin';
import { withNgxsFormPlugin } from '@ngxs/form-plugin';
import { withNgxsRouterPlugin } from '@ngxs/router-plugin';
import { withNgxsStoragePlugin } from '@ngxs/storage-plugin';
import { provideStore } from '@ngxs/store';
import { DessertsState } from './store/desserts/desserts.state';
import { CartState } from './store/cart/cart.state';
import { DeliveryAddressState } from './store/deliveryAddress/deliveryAddress.state';
import { CardPaymentState } from './store/cardPayment/cardPayment.state';
import { CheckOutState } from './store/checkOut/checkOut.state';
import { AuthState } from './store/auth/auth.state';

export const appConfig: ApplicationConfig = {
  providers: [
    provideZoneChangeDetection({ eventCoalescing: true }),
    provideRouter(routes), 
    provideClientHydration(withEventReplay()),
    provideHttpClient(withFetch()),
    provideStore(
      [
        DessertsState,
        CartState,
        DeliveryAddressState,
        CardPaymentState,
        CheckOutState,
        AuthState
      ],
      withNgxsReduxDevtoolsPlugin(),
      withNgxsFormPlugin(),
      withNgxsRouterPlugin(),
      withNgxsStoragePlugin({
        keys: [
          'DessertsState',
          'CartState',
          'DeliveryAddressState',
          'CardPaymentState',
          'CheckOutState',
          'AuthState',
        ]
      })
    )
  ]
};  
