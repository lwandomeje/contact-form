import { Component, inject, OnInit, signal, ChangeDetectionStrategy} from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormGroup, Validators, FormControl} from '@angular/forms';
import { Store } from '@ngxs/store';
import { Register } from '../../store/auth/auth.actions';
import { AuthState } from '../../store/auth/auth.state';
import { tap } from 'rxjs';
import { Router } from '@angular/router';
import { MatBottomSheet } from '@angular/material/bottom-sheet';
import { RegisterErrorSheetComponent } from '../../components/bottom-sheets/register-error-sheet/register-error-sheet.component';
import {MatIconModule} from '@angular/material/icon';


@Component({
  selector: 'app-register',
  imports: [
    ReactiveFormsModule,
    CommonModule,
    MatIconModule
],
  templateUrl: './register.component.html',
  styleUrl: './register.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class RegisterComponent implements OnInit {

  hidePassword = signal(true);
  clickEvent(event: MouseEvent) {
    this.hidePassword.set(!this.hidePassword());
    event.stopPropagation();
  }

  hideReEnterPassword = signal(true);
  clickEventReEnter(event: MouseEvent) {
    this.hideReEnterPassword.set(!this.hideReEnterPassword());
    event.stopPropagation();
  }

  
  private store = inject(Store);
  registerUserForm!: FormGroup;
  authError$ = this.store.select( AuthState.getErrorMessage || null);
  authError!: string | null;
  invalidPassword = false
  private bottomsheet = inject(MatBottomSheet)

  constructor(
    private readonly route: Router
  ){}

  ngOnInit(): void {

    this.authError$
    .pipe(
      tap( res => this.authError = res),
    ).subscribe()

    this.registerUserForm = new FormGroup ({
      email: new FormControl('', [Validators.required, Validators.email,Validators.pattern(/^\S+$/),]),
      password: new FormControl('', 
        [
          Validators.required,
          Validators.minLength(8),
          Validators.pattern(/^\S+$/),
          Validators.pattern(/^(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/)
        ]
      ),
      ReEnterPassword: new FormControl('',[Validators.required,])
    })

  };

  registerUser(){

    if(this.registerUserForm.get('password')?.value === this.registerUserForm.get('ReEnterPassword')?.value) {
      this.store.dispatch( new Register(
        this.registerUserForm.get('email')?.value,
        this.registerUserForm.get('password')?.value
      ))
    }

    if (this.authError == '' || this.authError == null) {
      this.bottomsheet.open(RegisterErrorSheetComponent, {
        data:{
          Title: "Registration Successful ✅",
          message: 'Your account has been created successfully'
        },
        disableClose: true
      })
    }

    if(this.authError == 'User already exists'){
      this.bottomsheet.open(RegisterErrorSheetComponent, {
        data:{
          Title: "Register Account Failed",
          message: 'User already exists'
        },
        disableClose: true
      })
    }

    if (this.registerUserForm.get('password')?.value !== this.registerUserForm.get('ReEnterPassword')?.value) {
      this.bottomsheet.open(RegisterErrorSheetComponent, {
        data:{
          Title: "Register Account Failed",
          message: 'invalid Password'
        },
        disableClose: true
      })
    }




  }

  
}
