import { Component,OnInit } from '@angular/core';
import {FormGroup,FormControl} from '@angular/forms';
import {MatRadioModule} from '@angular/material/radio';

@Component({
  selector: 'app-contact-form',
  imports: [MatRadioModule,],
  templateUrl: './contact-form.component.html',
  styleUrl: './contact-form.component.scss'
})
export class ContactFormComponent implements OnInit {

  isGeneralEnquirySelecte = false
  isSupportRequestSelecte = false
  contactForm!: FormGroup;

  ngOnInit(): void {

    this.contactForm = new FormGroup ({
      fistName: new FormControl('',[]),
      lastName: new FormControl('',[]),
      email: new FormControl('',[]),
      generalaEnquiry: new FormControl('',[]),
      supportRequest: new FormControl(false),
      message: new FormControl(false),
      consent: new FormControl(false)

    });
  }
  selectGeneralEnquiry(){
    this.isGeneralEnquirySelecte = true
    this.isSupportRequestSelecte = false
  }
  selectSupportRequest(){
    this.isSupportRequestSelecte = true
    this.isGeneralEnquirySelecte = false
  }


}
