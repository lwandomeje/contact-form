import { Component, inject, OnInit, signal  } from '@angular/core';
import { ReactiveFormsModule ,FormControl, FormGroup, Validators } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Store } from '@ngxs/store';
import { tap } from 'rxjs';
import { AuthState } from '../../store/auth/auth.state';
import { ResetPassword } from '../../store/auth/auth.actions';
import { MatIconModule } from '@angular/material/icon';
import { MatBottomSheet } from '@angular/material/bottom-sheet';
import { ResetPasswordSheetComponent } from '../../components/bottom-sheets/reset-password-sheet/reset-password-sheet.component';


@Component({
  selector: 'app-reset-password',
  imports: [
    ReactiveFormsModule, 
    CommonModule, 
    MatIconModule,
  ],
  templateUrl: './reset-password.component.html',
  styleUrl: './reset-password.component.scss'
})
export class ResetPasswordComponent implements OnInit {

  private store = inject(Store);
  resetPasswordForm!: FormGroup;
  AuthError$ = this.store.select( AuthState.getErrorMessage)
  AuthError!: string | null
  private matBottomSheet = inject(MatBottomSheet)

  hidePassword = signal(true);
  clickEvent(event: MouseEvent) {
    this.hidePassword.set(!this.hidePassword());
    event.stopPropagation();
  }

  hideReEnterPassword = signal(true);
  clickEventReEnter(event: MouseEvent) {
    this.hideReEnterPassword.set(!this.hideReEnterPassword());
    event.stopPropagation();
  }


  ngOnInit(): void {
    this.AuthError$
    .pipe(
      tap( res => this.AuthError = res),
    ).subscribe();

    this.resetPasswordForm = new FormGroup({
      email: new FormControl('', [Validators.required, Validators.email, Validators.pattern(/^\S+$/)]),
      password: new FormControl('', 
        [
          Validators.required,
          Validators.minLength(8),
          Validators.pattern(/^\S+$/),
          Validators.pattern(/^(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/)
        ]
      ),
      ReEnterPassword: new FormControl('',[Validators.required,])
    })

  }

  resetPassword(){

    if(this.resetPasswordForm.get('password')?.value === this.resetPasswordForm.get('ReEnterPassword')?.value){
      this.store.dispatch( new ResetPassword(
        this.resetPasswordForm.get('email')?.value,
        this.resetPasswordForm.get('password')?.value
      ))
    };

    if( this.AuthError == null || this.AuthError == '') {
      this.matBottomSheet.open(ResetPasswordSheetComponent, {
        data :{
          Title: 'Password reset successfully ✅',
          message: 'You can login with your new password'
        },
        disableClose: true
      })
    };

    if(this.AuthError === 'User not found') {
      this.matBottomSheet.open(ResetPasswordSheetComponent, {
        data: {
          Title: 'User not found',
          message: 'please check you email address '
        },
        disableClose: true
      })
    }

    if(this.AuthError === 'No OTP verification found. Please request an OTP first.') {
      this.matBottomSheet.open(ResetPasswordSheetComponent, {
        data: {
          Title: 'No OTP verification found',
          message: 'Please request an OTP first.'
        },
        disableClose: true
      })
    }

    if(this.AuthError === 'This email does not match the one used for OTP verification.') {
      this.matBottomSheet.open(ResetPasswordSheetComponent, {
        data: {
          Title: 'This email does not match the one used for OTP verification.',
          message: 'please check you email address, this email is not the one used On OPT verification'
        },
        disableClose: true
      })
    }

    if (this.resetPasswordForm.get('password')?.value != this.resetPasswordForm.get('ReEnterPassword')?.value) {
      this.matBottomSheet.open(ResetPasswordSheetComponent, {
        data: {
          Title: 'Invalid Password',
          message: 'please check you password'
        },
        disableClose: true
      })
    }

  }

  

}
