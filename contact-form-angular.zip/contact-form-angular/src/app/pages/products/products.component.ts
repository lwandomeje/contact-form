import {Component, inject, OnInit} from '@angular/core';
import {CommonModule } from '@angular/common'
import {ProductCardComponent } from '../../components/product-card/product-card.component';
import { CartComponent } from '../../components/cart/cart.component';
import {Dessert } from '../../inetrfaces/desserts.interface';
import {DessertsState } from '../../store/desserts/desserts.state';
import * as CartActions from '../../store/cart/cart.actions'
import {getDesserts } from '../../store/desserts/desserts.action';
import {Store } from '@ngxs/store';

@Component({
  selector: 'app-products',
  imports: [CommonModule, ProductCardComponent, CartComponent],
  templateUrl: './products.component.html',
  styleUrl: './products.component.scss'
})
export class ProductsComponent implements OnInit {
  private store = inject(Store)
  viewMode = "";
  desserts: Dessert[] = this.store.selectSnapshot(DessertsState.getAllDesserts)
  cakesCategory = this.store.selectSnapshot(DessertsState.getCakesCategory)
  wafflesCategory = this.store.selectSnapshot(DessertsState.getWafflesCategory)
  pieCategory = this.store.selectSnapshot(DessertsState.getPieCategory)
  brownieCategory = this.store.selectSnapshot(DessertsState.getBrownieCategory)
  
  haveDesserts!: boolean  

  ngOnInit(): void {
    this.store.dispatch(new getDesserts());
    if(this.desserts.length > 0) {
      this.haveDesserts = true
    }else{
      this.haveDesserts = false
    }
  }

  onAddToCart(item: Dessert ){
    this.store.dispatch( new CartActions.AddDessertToCart(item))
    this.store.dispatch( new CartActions.updateDessert({productId: item.productId, isInCart: true, quantity: 1}))
  }

  incrementDessert(event:{ quantity: number; dessert: Dessert }){    
    this.store.dispatch( new CartActions.updateDessert({productId: event.dessert.productId, isInCart: true, quantity: event.quantity +1}))
  }

  decrementDesset(event:{ quantity: number; dessert: Dessert }){
    this.store.dispatch( new CartActions.updateDessert({productId:event.dessert.productId, isInCart: true, quantity: Math.max((event.quantity)-1,0)}))
    if (event.quantity === 1) {
      this.store.dispatch( new CartActions.updateDessert({productId:event.dessert.productId, isInCart: false, quantity:0}))
      this.store.dispatch( new CartActions.RemoveDessertFomCart(event.dessert))
    }
  }
  

}

