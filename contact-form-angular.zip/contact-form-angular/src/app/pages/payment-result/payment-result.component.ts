import { Component, inject, OnInit } from '@angular/core';
import { ReactiveFormsModule, FormGroup, FormControl , Validators} from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Store } from '@ngxs/store';
import { resetCartState } from '../../store/cart/cart.actions';
import { CheckOutState } from '../../store/checkOut/checkOut.state';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { NotificationsService } from '../../services/notifications.service';
import { emailRequest } from '../../inetrfaces/emailjs.interface';

@Component({
  selector: 'app-payment-result',
  imports: [
    FormsModule,
    ReactiveFormsModule,
    CommonModule
  ],
  templateUrl: './payment-result.component.html',
  styleUrl: './payment-result.component.scss'
})
export class PaymentResultComponent implements OnInit {

  private store = inject(Store);
  checkOutObject = this.store.selectSnapshot(CheckOutState.getCheckOut);
  notificationRequestBody!:emailRequest;
  emailForm!: FormGroup;


  constructor(
    private route : Router,
    private notification: NotificationsService
  ){}

  ngOnInit(): void {

    this.emailForm = new FormGroup({
      customerEmail: new FormControl('',[Validators.required, Validators.email,Validators.pattern(/^\S+$/)])
    })

    this.notificationRequestBody = {
      checkOutId: this.checkOutObject.checkOutId,
      date: this.checkOutObject.date,
      locationName: this.checkOutObject.address.locationName,
      cart: this.checkOutObject.cart,
      brand: this.checkOutObject.payment.brand,
      last4: this.checkOutObject.payment.last4,
      expiryMonth: this.checkOutObject.payment.expiryMonth,
      expiryYear: this.checkOutObject.payment.expiryYear,
      checkOutTotal: this.checkOutObject.checkOutTota
    }
    
  }

  backToHome(){
    this.notification.sendOrderSummary(this.notificationRequestBody,this.emailForm.get('customerEmail')?.value)
    .then(res => console.log('Order confirmation sent!', res))
    .catch(err => console.log('Error sending order confirmation', err))
    this.store.dispatch( new resetCartState())
    this.route.navigateByUrl('')
  }

}
