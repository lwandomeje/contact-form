import { Component, inject, OnInit} from '@angular/core';
import { ReactiveFormsModule, FormGroup, FormControl, Validators} from '@angular/forms';
import { CommonModule } from '@angular/common';
import { IsOTPSent, SendOtp,  } from '../../store/auth/auth.actions';
import { AuthState } from '../../store/auth/auth.state';
import { Store } from '@ngxs/store';
import { Subject, tap } from 'rxjs';
import { MatBottomSheet } from '@angular/material/bottom-sheet';
import { ForgotPasswordSheetComponent } from '../../components/bottom-sheets/forgot-password-sheet/forgot-password-sheet.component';



@Component({
  selector: 'app-forgot-password',
  imports: [ReactiveFormsModule, CommonModule],
  templateUrl: './forgot-password.component.html',
  styleUrl: './forgot-password.component.scss'
})
export class ForgotPasswordComponent implements OnInit {
  private descroy$ = new Subject<void>();
  private store = inject(Store);
  sendOPTForm!: FormGroup;
  AuthError$ = this.store.select( AuthState.getErrorMessage);
  AuthError!: string | null
  private bottomsheet = inject(MatBottomSheet)


  ngOnInit(): void {

    this.store.dispatch( new IsOTPSent())
    
    this.AuthError$
    .pipe(
      tap( res => this.AuthError = res),
    ).subscribe()

    this.sendOPTForm = new FormGroup({
      email: new FormControl('', [Validators.required, Validators.email, Validators.pattern(/^\S+$/)])
    })
  }

  sendOTP(){

    if (this.sendOPTForm.valid) {
      this.store.dispatch(new SendOtp(this.sendOPTForm.get('email')?.value))
    }

    if( this.AuthError == null || this.AuthError == 'Http failure during parsing for https://api.emailjs.com/api/v1.0/email/send'){
      this.bottomsheet.open( ForgotPasswordSheetComponent, {
        data:{
          Title:'Email Sent to you email',
          message: 'you can revify OTP'
        },
        disableClose: true,
      })
    }

    if (this.AuthError === 'User not found') {
      this.bottomsheet.open( ForgotPasswordSheetComponent, {
        data:{
          Title:'User not found',
          message: 'Please check your email address'
        },
        disableClose: true,
      })
    }

  }



}
