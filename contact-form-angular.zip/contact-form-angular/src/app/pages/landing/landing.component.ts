import { Component, OnDestroy, OnInit } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { CommonModule } from '@angular/common';
import { DessertsService } from '../../services/desserts.service';
import { Subject, takeUntil } from 'rxjs';
import { Router } from '@angular/router';


@Component({
  selector: 'app-landing',
  imports: [CommonModule, MatIconModule],
  templateUrl: './landing.component.html',
  styleUrl: './landing.component.scss'
})
export class LandingComponent implements OnInit, OnDestroy {
  private destroy$ = new Subject<void>()
  listOfUsers: { name: string; comment: string }[] = [];
  haveUsers = false;


  constructor(
    private dessertService: DessertsService,
    private router: Router
  ){
  }
  

  ngOnInit(): void {
    this.dessertService.getUsers()
    .pipe(takeUntil(this.destroy$))
    .subscribe(useres => {
      this.listOfUsers = useres.map((user, i) =>{
        const commentIndex = i% this.dessertService.comment.length;
        const comment = this.dessertService.comment[commentIndex]
        return {
          name: user.name,
          comment: comment
        };
      });
      if (this.listOfUsers.length > 0) {        
        this.haveUsers = true
      }
    })
  }

  goTomenu(){
    this.router.navigateByUrl('/products')
  }

  lastCheckOut(){
    this.router.navigateByUrl('/last-check-out')
  }



  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete()
  }

}
