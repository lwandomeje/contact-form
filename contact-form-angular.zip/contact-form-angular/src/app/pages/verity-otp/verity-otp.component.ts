import { Component, inject, OnInit, OnDestroy } from '@angular/core';
import { ReactiveFormsModule, FormGroup, FormControl, Validators } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Store } from '@ngxs/store';
import { AuthState } from '../../store/auth/auth.state';
import { VerifyOtp } from '../../store/auth/auth.actions';
import { Subject, takeUntil, tap } from 'rxjs';
import { MatBottomSheet } from '@angular/material/bottom-sheet';
import { VerifyPasswordOtpSheetComponent } from '../../components/bottom-sheets/verify-password-otp-sheet/verify-password-otp-sheet.component';

@Component({
  selector: 'app-verity-otp',
  imports: [ ReactiveFormsModule, CommonModule ],
  templateUrl: './verity-otp.component.html',
  styleUrl: './verity-otp.component.scss'
})
export class VerityOtpComponent implements OnInit, OnDestroy {

  private destroy$ = new Subject<void>();
  private store = inject(Store);
  verifyOTPForm!: FormGroup;
  AuthError$ = this.store.select( AuthState.getErrorMessage)
  AuthError!: string | null
  bottomSheet = inject(MatBottomSheet)

  ngOnInit(): void {

    this.AuthError$
    .pipe(
      tap( res => this.AuthError = res),
      takeUntil( this.destroy$)
    ).subscribe();

    this.verifyOTPForm = new FormGroup({
      email: new FormControl('', [Validators.required, Validators.email, Validators.pattern(/^\S+$/)]),
      otp: new FormControl('',[Validators.required,])
    })

  }

  verify(){

    if(this.verifyOTPForm){
      this.store.dispatch( new VerifyOtp(
        this.verifyOTPForm.get('email')?.value,
        this.verifyOTPForm.get('otp')?.value
      ))
    };

    if( this.AuthError == null || this.AuthError == '') {
      this.bottomSheet.open(VerifyPasswordOtpSheetComponent, {
        data: {
          Title:'OPT verification success ✅',
          message: 'your account verification completed successfuly, now you can reset your password ',
        },
        disableClose: true
      })
    };

    if(this.AuthError == 'No OTP requested') {
      this.bottomSheet.open(VerifyPasswordOtpSheetComponent, {
        data: {
          Title: 'No OTP requested',
          message: 'Please request an OTP first.',
        },
        disableClose: true     
      })
    }

    if(this.AuthError == 'Invalid or expired OTP') {
      this.bottomSheet.open(VerifyPasswordOtpSheetComponent, {
        data: {
          Title: 'Invalid or expired OTP',
          message: 'please cheack you email address or OTP, OPT is valid for 5 minutes, ',
        },
        disableClose: true
      })
    }

  }

  ngOnDestroy(): void {
    this.destroy$.next()
    this.destroy$.complete()
  }
}
