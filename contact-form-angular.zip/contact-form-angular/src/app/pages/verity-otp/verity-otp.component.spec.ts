import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VerityOtpComponent } from './verity-otp.component';

describe('VerityOtpComponent', () => {
  let component: VerityOtpComponent;
  let fixture: ComponentFixture<VerityOtpComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [VerityOtpComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(VerityOtpComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
