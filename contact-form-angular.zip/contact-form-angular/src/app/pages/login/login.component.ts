import { Component, OnInit, inject, signal, ChangeDetectionStrategy} from '@angular/core';
import { ReactiveFormsModule, FormGroup, FormControl, Validators } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Store } from '@ngxs/store';
import * as authActions from  '../../store/auth/auth.actions'
import { AuthState } from '../../store/auth/auth.state';
import { Router } from '@angular/router';
import { MatIconModule} from '@angular/material/icon';
import { MatBottomSheet } from '@angular/material/bottom-sheet';
import { LoginSheetComponent } from '../../components/bottom-sheets/login-sheet/login-sheet.component';
import { tap } from 'rxjs';

@Component({
  selector: 'app-login',
  imports: [
    ReactiveFormsModule, 
    CommonModule,
    MatIconModule,
  ],
  templateUrl: './login.component.html',
  styleUrl: './login.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class LoginComponent implements OnInit {

  hide = signal(true);
  clickEvent(event: MouseEvent) {
    this.hide.set(!this.hide());
    event.stopPropagation();
  }

  private store = inject(Store)
  loginForm! : FormGroup
  isAuth$ = this.store.select( AuthState.getIsAuth)
  isAuth!: boolean
  authError$ = this.store.select( AuthState.getErrorMessage || null);
  authError!: string | null;
  private bottomsheet = inject(MatBottomSheet)

  constructor(
    private readonly route: Router
  ){}

  ngOnInit(): void {
    this.isAuth$
    .pipe(
      tap( res => this.isAuth = res),
    ).subscribe()

    this.authError$
    .pipe(
      tap( res => this.authError = res),
    ).subscribe()

    this.loginForm = new FormGroup({

      email: new FormControl('', [Validators.required, Validators.email,Validators.pattern(/^\S+$/)]),
      password: new FormControl('', 
        [
          Validators.required,
          Validators.minLength(8),
          Validators.pattern(/^\S+$/),
          Validators.pattern(/^(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/)
        ]
      ),

    });
    
  }

  Login(){

    if(this.loginForm){
      this.store.dispatch(new authActions.Login(
        this.loginForm.get('email')?.value,
        this.loginForm.get('password')?.value
      ))

    }

    if (this.authError === 'Invalid credentials') {
      this.bottomsheet.open(LoginSheetComponent,{
        data: {
          Title: "Login Failed",
          message: 'Invalid credentials.Please check your email and password'
        },
        disableClose: true,
      })
    }


    if(this.isAuth){
      this.route.navigateByUrl('/landing')
    }
  }

  registerPage(){
    this.route.navigateByUrl('/register')
  }

  forgotPasswordPage(){
    this.route.navigateByUrl('/forgot-password')
  }

}
