import { Component, inject, OnInit, OnDestroy } from '@angular/core';
import { CommonModule, Location } from '@angular/common';
import { Dessert } from '../../inetrfaces/desserts.interface';
import { ConfirmedCartComponent } from '../../components/confirmed-cart/confirmed-cart.component';
import { DeliveryLocationComponent } from '../../components/delivery-location/delivery-location.component';
import { SelectedAddressComponent } from '../../components/selected-address/selected-address.component';
import { AddCardFormComponent } from '../../components/add-card-form/add-card-form.component';
import { SavedPaymentCardComponent } from '../../components/saved-payment-card/saved-payment-card.component';
import { TipCalculatorComponent } from '../../components/tip-calculator/tip-calculator.component';
import { Store } from '@ngxs/store';
import { DeliveryAddressState } from '../../store/deliveryAddress/deliveryAddress.state';
import { CardPaymentState } from '../../store/cardPayment/cardPayment.state';
import { Subject, takeUntil, tap, SubscriptionLike } from 'rxjs';
import { CartState } from '../../store/cart/cart.state';
import { PayCheckOut, setCheckOut } from '../../store/checkOut/checkOut.actions';
import { CheckOutState } from '../../store/checkOut/checkOut.state';
import { v4 as uuidv4 } from 'uuid'

// import { CheckOutState } from '../../store/checkOut/checkOut.state';
import { Router } from '@angular/router';

@Component({
  selector: 'app-check-out',
  imports: [
    DeliveryLocationComponent,
    SelectedAddressComponent,
    AddCardFormComponent,
    SavedPaymentCardComponent,
    TipCalculatorComponent,
    CommonModule,
    ConfirmedCartComponent,
  ],
  templateUrl: './check-out.component.html',
  styleUrl: './check-out.component.scss'
})
export class CheckOutComponent implements OnInit, OnDestroy  {
  
  private destroy$ = new Subject<void>();
  private store = inject(Store);
  selectAddress$ = this.store.select(DeliveryAddressState.getdeviveryAddress);
  cartTotal$ = this.store.select(CartState.getTotalCartPrice);
  cartItems$ = this.store.select(CartState.getAllCartItems);
  deviveryAddress$ = this.store.select(DeliveryAddressState.getdeviveryAddress)
  peachCardToken$ = this.store.select(CardPaymentState.getpeachCardToken);
  checkOutObject = this.store.selectSnapshot(CheckOutState.getCheckOut)
  payed$ = this.store.select(CheckOutState.getIsPayed) 

  havelocation!: boolean;
  locationName!: string;
  cartItems!: Dessert[]
  token!:string;    
  brand!:string;   
  last4!:string;    
  expiryMonth!:string;
  expiryYear!:string;
  isCardSaved!: boolean;

  totalCheckOutWithTip!: number;
  totalCheckOut!: number;
  private sub!: SubscriptionLike;

  constructor( 
    private readonly route: Router,
    private location: Location
  ){ 
  }

  ngOnInit(): void {
    this.store.dispatch( new PayCheckOut(false))
    this.selectAddress$
    .pipe(
      tap((res) => {
        // eslint-disable-next-line @typescript-eslint/no-unused-expressions
        this.havelocation = res.haveLocation,
        this.locationName = res.locationName
      }),
      takeUntil(this.destroy$)
    ).subscribe()

    this.peachCardToken$
    .pipe(
      tap((res) => {
        // eslint-disable-next-line @typescript-eslint/no-unused-expressions
        this.token = res.token,    
        this.brand = res.brand,   
        this.last4 = res.last4,    
        this.expiryMonth = res.expiryMonth,
        this.expiryYear = res.expiryYear,
        this.isCardSaved = res.isCardSaved ?? false
    }),
      takeUntil(this.destroy$)
    ).subscribe()

    this.cartTotal$
    .pipe(
      tap( (res) => 
        {
          this.totalCheckOut = res;
          // this.totalCheckOutWithTip = res
        }

      ),
      takeUntil(this.destroy$)
    ).subscribe()

    this.cartItems$
    .pipe(
      tap( (res) => {
        this.cartItems = res;
      }),
      takeUntil( this.destroy$)
    ).subscribe()

  

  }

  totalPriceWithTip(value:number){
    this.totalCheckOutWithTip = value
  }

  payWithTip(){
    if(!this.totalCheckOutWithTip || this.totalCheckOut == this.totalCheckOutWithTip){
      this.store.dispatch( new setCheckOut({
      checkOutId: uuidv4(),
      date: new Date().toLocaleString(),
      cart: this.cartItems,
      address: {
        locationName: this.locationName,
        haveLocation: this.havelocation
      },
      payment:{
        token: this.token,
        brand: this.brand,
        last4: this.last4,
        expiryMonth: this.expiryMonth,
        expiryYear: this.expiryYear,
        isCardSaved: this.isCardSaved
      },
      checkOutTota: this.totalCheckOut 
      }));
      this.store.dispatch( new PayCheckOut(true))
      this.route.navigateByUrl('/payment-result')

    } else if(this.totalCheckOut !== this.totalCheckOutWithTip){
      this.store.dispatch( new setCheckOut({
      checkOutId: uuidv4(),
      date: new Date().toLocaleString(),
      cart: this.cartItems,
      address: {
        locationName: this.locationName,
        haveLocation: this.havelocation
      },
      payment:{
        token: this.token,
        brand: this.brand,
        last4: this.last4,
        expiryMonth: this.expiryMonth,
        expiryYear: this.expiryYear,
        isCardSaved: this.isCardSaved
      },
      checkOutTota: this.totalCheckOutWithTip 
      }));
      this.store.dispatch( new PayCheckOut(true))
      this.route.navigateByUrl('/payment-result')
    }
   
  }

  ngOnDestroy(): void {
    this.destroy$.next()
    this.destroy$.complete()
  }

}


