import { Injectable, Inject, PLATFORM_ID } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { NotificationsService } from './notifications.service';
import { Observable, of, throwError } from 'rxjs';
import { v4 as uuidv4 } from 'uuid'

@Injectable({
  providedIn: 'root'
})

//Right now  AuthService is pretending to be your backend because I don’t yet have an actual API/database.

export class AuthServiceService {

  USERS_KEY = 'app_users';   // localStorage to store all registered users 
  OTP_KEY = 'reset_otp';      // localStorage key for OTP
  LOGGED_IN_KEY = 'loggedInUser';


  constructor(
    private notification: NotificationsService,
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    @Inject(PLATFORM_ID) private platformID : any
  ) { }
  

  //🔒 Helpers
  private getUsers(){
    if(isPlatformBrowser(this.platformID)){
      return JSON.parse(localStorage.getItem(this.USERS_KEY) || '{}')
    }
    return {}
  }

  private generateOtp(): string {
    return Math.floor(100000 + Math.random() * 900000).toString(); // 6-digit OTP
  }


  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  register (email: string, password: string): Observable<any> {
    const users = this.getUsers();
    if(users[email]){
      return throwError(() => new Error('User already exists'))
    }
    if (isPlatformBrowser(this.platformID)) {
      users[email] = {password: password, userID: uuidv4()};
      localStorage.setItem(this.USERS_KEY, JSON.stringify(users))
    }
    return of({success: true})
  }


  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  login(email: string, password: string):Observable<any>{
    const users = this.getUsers();

    if (isPlatformBrowser(this.platformID)) {
      if (users[email] && users[email].password === password) {
        const loggedUserData = { email: email, userID: users[email].userID}
        sessionStorage.setItem(this.LOGGED_IN_KEY, JSON.stringify(loggedUserData))
        return of({success: true})
      }
    }

    return throwError(() => new Error('Invalid credentials'))
  }


  // Logs out user.
  logout(){
    if (isPlatformBrowser(this.platformID)) {
      sessionStorage.removeItem(this.LOGGED_IN_KEY)
    }
    
  }

  // Send OTP to user's email for password reset.
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  sendPasswordResetOtp(email: string): Observable<any>{
    const users = this.getUsers();
    if (!users[email]) {
      return throwError(() => new Error('User not found'));
    }
    const otp = this.generateOtp();
    const expiresAt = Date.now() + 5 * 60 * 1000; // valid for 5 minutes
    // Save OTP in localStorage
    localStorage.setItem(this.OTP_KEY, JSON.stringify({ email, otp, expiresAt}))
    // Use NotificationsService to send via EmailJS
    return this.notification.sendOTP( email, otp, expiresAt )
  }



  // Verify OTP entered by the user.
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  verifyOTP(email: string, otp: string): Observable<any> {
    const data = localStorage.getItem(this.OTP_KEY);

    if(!data) {
      return throwError(() => new Error('No OTP requested'));
    }

    const { email: storedEmail, otp: storedOtp, expiresAt } = JSON.parse(data);
    if (storedEmail === email && storedOtp === otp && Date.now() < expiresAt) {
      return of({ success: true });
    }

    return throwError(() => new Error('Invalid or expired OTP'));
  }



  // Reset password after OTP verification.
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  resetPassword(email: string, newPassword: string): Observable<any> {
    const otpData = localStorage.getItem(this.OTP_KEY);
    const users = this.getUsers();
    if(!users[email]){
      return throwError (() => new Error('User not found'))
    }
    if (!otpData) {
      return throwError(() => new Error('No OTP verification found. Please request an OTP first.'));
    }

    const { email: storedEmail } = JSON.parse(otpData);

    if (storedEmail !== email) {
      return throwError(() => new Error('This email does not match the one used for OTP verification.'));
    }

    users[email].password = newPassword;
    localStorage.setItem(this.USERS_KEY, JSON.stringify(users))
    localStorage.removeItem(this.OTP_KEY)
    return of({ success: true });
  }



}
