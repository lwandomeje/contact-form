import { TestBed } from '@angular/core/testing';

import { PeachPaymentService } from './peach-payment.service';

describe('PeachPaymentService', () => {
  let service: PeachPaymentService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(PeachPaymentService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
