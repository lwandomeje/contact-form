/* eslint-disable @typescript-eslint/no-explicit-any */
import { Injectable } from '@angular/core';
import { HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LeafletNominatimService {

  constructor(private http: HttpClient) {}

  private GeobaseUrl = 'https://photon.komoot.io'
  private searchbaseUrl = 'https://photon.komoot.io/api/'

  reverseGeocode(lat: number, lon: number): Observable<any> {
    const url = `${this.GeobaseUrl}/reverse?lat=${lat}&lon=${lon}&limit=1`;
    return this.http.get<any>(url);
  }

  searchLocation(searchStr: string): Observable<any> {
    const url = `${this.searchbaseUrl}?q=${encodeURIComponent(searchStr)}&limit=5`;
    return this.http.get<any>(url);
  }
}



