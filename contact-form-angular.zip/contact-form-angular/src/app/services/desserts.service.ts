import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable,} from 'rxjs';
import { User } from '../inetrfaces/users.interface';
import { Dessert } from '../inetrfaces/desserts.interface';
  
@Injectable({
  providedIn: 'root'
})
export class DessertsService {

  comment = [
    "Best cheesecake I’ve ever had!",
    'Cupcakes were fresh and fluffy.',
    'The chocolate mousse was heavenly.',
    'Loved the quick delivery and tasty treats.',
    'Brownies were rich and fudgy — so good!',
    'Ice cream was creamy and full of flavor.',
    'Perfect balance of sweetness, not overwhelming.',
    'Macarons were delicate and delicious.',
    'Great variety of desserts to choose from.',
    'The tiramisu slice was spot on — loved it!',
  ]

  constructor(
    private http: HttpClient
  ) {}

  getDesserts(): Observable<Dessert[]>{
    const url = 'assets/data.json'
    return this.http.get<Dessert[]>(url)
  }

  getUsers(): Observable<User[]>{
    const url = 'https://jsonplaceholder.typicode.com/users'
    const httpOptions = {
      headers: new HttpHeaders({
        'x-api-key': 'reqres-free-v1'
      })
    }
    return this.http.get<User[]>(url, httpOptions) 
  }
}
