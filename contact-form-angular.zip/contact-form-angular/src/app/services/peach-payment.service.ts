import { Injectable } from '@angular/core';
import { PeachCardToken, PeachCard } from '../inetrfaces/peachCardToken.interface';
import { delay, Observable, of } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class PeachPaymentService {

//MockPeachPaymentsService — simulates token creation safely
//simulates contacting a payment gateway and returns a mock token object with safe card info.

  createToken(card:PeachCard):Observable<PeachCardToken>{
    let brand = 'UnKnown';
    if (card.cardNumber.startsWith('4')){
      brand = 'Visa'
    }else if(card.cardNumber.startsWith('5')){
      brand = 'MasterCard'
    };

    const token: PeachCardToken ={
      token: 'mock_token_' + Math.random().toString(36).slice(2, 12),
      brand,
      last4: card.cardNumber.slice(-4),
      expiryMonth: card.expiryMonth,
      expiryYear: card.expiryYear
    };

    return of(token).pipe(delay(500))

  }

  //Then post the peachPay SDK reasponse to backend API



}
