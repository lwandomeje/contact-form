import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';
import { emailRequest } from '../inetrfaces/emailjs.interface';
import { Dessert } from '../inetrfaces/desserts.interface';


@Injectable({
  providedIn: 'root'
})
export class NotificationsService {

  private apiUrl = 'https://api.emailjs.com/api/v1.0/email/send';
  private serviceID = 'service_grhuz5k';
  private orderSummaryTemplateID = 'template_g41vycp';
  private otpTemplateID = 'template_y5hhcrb';
  private publicKey = 'pV7p8-5Tx5S6s6bGh';

  constructor(
    private http : HttpClient
  ) { }


  sendOTP(toEmail: string, otp: string, expiresAt: number){
    const body = {
      service_id: this.serviceID,
      template_id: this.otpTemplateID,
      user_id: this.publicKey,
      template_params: {
        to_email: toEmail,
        otp,
        expires: new Date(expiresAt).toString()
      }
    }
    return this.http.post(this.apiUrl, body)
  }


  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  sendOrderSummary(checkOut: emailRequest, customerEmail: string): Promise<any> {
    
    const templateParams = {
      to_email: customerEmail,
      checkOutId: checkOut.checkOutId,
      date: checkOut.date,
      locationName: checkOut.locationName,
      cart: checkOut.cart.map((item: Dessert) => `${item.name} x${item.quantity}`).join(','),
      brand: checkOut.brand,
      last4: checkOut.last4,
      expiryMonth: checkOut.expiryMonth,
      expiryYear: checkOut.expiryYear,
      checkOutTotal: checkOut.checkOutTotal
    };
    const body = {
      service_id: this.serviceID,
      template_id: this.orderSummaryTemplateID,
      user_id: this.publicKey,
      template_params: templateParams
    };
    return firstValueFrom(this.http.post(this.apiUrl, body));

  }

}
