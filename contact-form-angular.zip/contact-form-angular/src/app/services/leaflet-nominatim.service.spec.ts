import { TestBed } from '@angular/core/testing';

import { LeafletNominatimService } from './leaflet-nominatim.service';

describe('LeafletNominatimService', () => {
  let service: LeafletNominatimService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(LeafletNominatimService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
