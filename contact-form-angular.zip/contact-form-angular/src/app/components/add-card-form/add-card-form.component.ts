import { Component, inject, OnInit } from '@angular/core';
import { ReactiveFormsModule, FormGroup, FormControl, Validators } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Store } from '@ngxs/store';
import { addCardDetails } from '../../store/cardPayment/cardPayment.actions';


@Component({
  selector: 'app-add-card-form',
  imports: [ReactiveFormsModule, CommonModule],
  templateUrl: './add-card-form.component.html',
  styleUrl: './add-card-form.component.scss'
})
export class AddCardFormComponent implements OnInit {
  private store = inject(Store)
  cardDetailsForm!: FormGroup;

  ngOnInit(): void {

    this.cardDetailsForm = new FormGroup({
      CardHolderName: new FormControl('',[Validators.required, Validators.minLength(3)]),
      cardNumber: new FormControl('',[Validators.required, Validators.pattern('^[4|5][0-9]{15}$')]),// exactly 16 digits, starts with 4 or 5
      expiryMonth: new FormControl('',[Validators.required, Validators.pattern('^(0[1-9]|1[0-2])$')]),// 01 to 12
      expiryYear: new FormControl('',[Validators.required, Validators.pattern('^\\d{2}$'),Validators.min(new Date().getFullYear() % 100)]),// exactly 2 digits and must not be less than current year
      cvv: new FormControl('',[Validators.required, Validators.pattern('^\\d{3}$')])// exactly 3 digits
    });
  }

  onSubmit():void{

    if(this.cardDetailsForm.valid){
      this.store.dispatch(new addCardDetails({
        cardHolder: this.cardDetailsForm.get('CardHolderName')?.value ??'',
        cardNumber: this.cardDetailsForm.get('cardNumber')?.value ??'',
        expiryMonth: this.cardDetailsForm.get('expiryMonth')?.value ??'',
        expiryYear: this.cardDetailsForm.get('expiryYear')?.value ??'',
        cvv: this.cardDetailsForm.get('cvv')?.value ??''
      }))
    };
    
  }


}

