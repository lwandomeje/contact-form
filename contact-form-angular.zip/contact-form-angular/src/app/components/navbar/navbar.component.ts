import { Component,inject, OnInit} from '@angular/core';
import { CommonModule } from '@angular/common';
import { NavigationEnd, Router, RouterModule } from '@angular/router';
import { Store } from '@ngxs/store';
import { AuthState } from '../../store/auth/auth.state';
import { filter } from 'rxjs';



@Component({
  selector: 'app-navbar',
  imports: [RouterModule, CommonModule],
  templateUrl: './navbar.component.html',
  styleUrl: './navbar.component.scss'
})
export class NavbarComponent implements OnInit{
  private store = inject(Store)
  isAuth$ = this.store.select(AuthState.getIsAuth) 
  showNav = true
  currentUrl = ''

  constructor(private router: Router) {}

  ngOnInit(): void {
    this.router.events
      .pipe(filter(event => event instanceof NavigationEnd))
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      .subscribe((event: any) => {
        this.currentUrl = event.urlAfterRedirects;
        this.showNav = !this.currentUrl.includes('/last-check-out');
      });
    
    
  }
  
}
