import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Store } from '@ngxs/store';
import { CardPaymentState } from '../../store/cardPayment/cardPayment.state';
import { resetCardDetails } from '../../store/cardPayment/cardPayment.actions';


@Component({
  selector: 'app-saved-payment-card',
  imports: [CommonModule],
  templateUrl: './saved-payment-card.component.html',
  styleUrl: './saved-payment-card.component.scss'
})
export class SavedPaymentCardComponent {

    private store = inject(Store)
    cardDetails$ = this.store.select(CardPaymentState.getpeachCardToken)

    resetState(){
    console.log('resetState clicked ');
    this.store.dispatch(new resetCardDetails())
  }

}
