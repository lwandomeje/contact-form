import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SavedPaymentCardComponent } from './saved-payment-card.component';

describe('SavedPaymentCardComponent', () => {
  let component: SavedPaymentCardComponent;
  let fixture: ComponentFixture<SavedPaymentCardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SavedPaymentCardComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SavedPaymentCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
