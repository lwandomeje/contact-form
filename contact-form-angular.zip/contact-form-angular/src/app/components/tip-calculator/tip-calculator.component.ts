import { Component, inject, OnInit, OnDestroy, Output, EventEmitter} from '@angular/core';
import { CartState } from '../../store/cart/cart.state';
import { Store } from '@ngxs/store';
import { Subject, takeUntil, tap } from 'rxjs';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-tip-calculator',
  imports: [CommonModule],
  templateUrl: './tip-calculator.component.html',
  styleUrl: './tip-calculator.component.scss'
})
export class TipCalculatorComponent implements OnInit, OnDestroy {

  private store = inject(Store);
  private destroy$ = new Subject<void>();
  cartTotal$ = this.store.select (CartState.getTotalCartPrice);
  tipAmount: number | null = null;
  @Output() totalAmount = new EventEmitter<number>()
  cartTotal!: number;

  ngOnInit(): void {

   this.cartTotal$
   .pipe(
      tap( res => this.cartTotal = res),
      takeUntil(this.destroy$)
    ).subscribe()
    
  }

  calculateTip(percent: number){
    this.tipAmount = this.cartTotal * (percent/100)
    this.tipAmount = Number(this.tipAmount.toFixed(2))
    this.totalAmount.emit(this.cartTotal + this.tipAmount)
  }

  ngOnDestroy(): void {
    this.destroy$.next()
    this.destroy$.complete()
  }
}
