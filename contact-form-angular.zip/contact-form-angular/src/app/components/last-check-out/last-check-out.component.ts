import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Store } from '@ngxs/store';
import { CheckOutState } from '../../store/checkOut/checkOut.state';
import { AddDessertToCart } from '../../store/cart/cart.actions';
import { Router } from '@angular/router';


@Component({
  selector: 'app-last-check-out',
  imports: [CommonModule],
  templateUrl: './last-check-out.component.html',
  styleUrl: './last-check-out.component.scss'
})
export class LastCheckOutComponent {
 private store = inject(Store)
 lastCheckOut = this.store.selectSnapshot(CheckOutState.getCheckOut)

 constructor(
  private router : Router
 ){}

 addToCart(){
  this.lastCheckOut.cart.map( 
    dessert => this.store.dispatch(new AddDessertToCart(dessert))
  )
  this.router.navigateByUrl('/products')
 }

 orderNow(){
    this.router.navigateByUrl('/products')
 }
 
}
