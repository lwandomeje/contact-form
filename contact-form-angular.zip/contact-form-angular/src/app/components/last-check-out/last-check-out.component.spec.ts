import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LastCheckOutComponent } from './last-check-out.component';

describe('LastCheckOutComponent', () => {
  let component: LastCheckOutComponent;
  let fixture: ComponentFixture<LastCheckOutComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [LastCheckOutComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(LastCheckOutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
