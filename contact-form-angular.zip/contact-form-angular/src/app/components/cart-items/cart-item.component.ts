import { Component, EventEmitter, inject, Input, Output} from '@angular/core';
import { Dessert } from '../../inetrfaces/desserts.interface';
import { Store } from '@ngxs/store';
import { CartState } from '../../store/cart/cart.state';
import { map } from 'rxjs';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-cart-item',
  imports: [CommonModule],
  templateUrl: './cart-item.component.html',
  styleUrl: './cart-item.component.scss'
})
export class CartItemComponent {
  private store = inject(Store)
  @Input() cartItem!: Dessert;
  @Output() removeDessert = new EventEmitter<Dessert>();

  dessertTotalPrice$ = this.store.select(CartState.getSingleTotal)
  .pipe(
    map(selectorFn => selectorFn(this.cartItem.productId))
  )

  removeItem(){
    this.removeDessert.emit(this.cartItem) 
  }
}
