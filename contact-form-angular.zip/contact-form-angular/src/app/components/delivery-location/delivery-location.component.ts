import { Component, AfterViewInit, OnDestroy, inject,Inject } from '@angular/core';
import { CommonModule, isPlatformBrowser } from '@angular/common';
import { PLATFORM_ID } from '@angular/core';
import { debounceTime, Subject, takeUntil } from 'rxjs';
import { Store } from '@ngxs/store';
import { saveLocation } from '../../store/deliveryAddress/delivery.actions';
import { LeafletNominatimService } from '../../services/leaflet-nominatim.service';
// Leaflet imports
import * as L from 'leaflet';


// Configure default marker icon
const DefaultIcon = L.icon({
  iconRetinaUrl: 'assets/leaflet/marker-icon-2x.png',
  iconUrl: 'assets/leaflet/marker-icon.png',
  shadowUrl: 'assets/leaflet/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
});
L.Marker.prototype.options.icon = DefaultIcon;

@Component({
  selector: 'app-delivery-location',
  imports: [CommonModule],
  templateUrl: './delivery-location.component.html',
  styleUrls: ['./delivery-location.component.scss']
})
export class DeliveryLocationComponent implements AfterViewInit, OnDestroy {
  private destroy$ = new Subject<void>();
  private searchSubject = new Subject<string>();

  private map!: L.Map;
  private marker!: L.Marker;
  selectedLocation!: L.LatLng;
  selectedAddressName = '';

  private store = inject(Store);

  constructor(
    @Inject(PLATFORM_ID) private platformId: object,
    private leafletNominatimService: LeafletNominatimService
  ) {
    this.searchSubject
      .pipe(debounceTime(500), takeUntil(this.destroy$))
      .subscribe((searchStr) => this.performSearch(searchStr));
  }

  ngAfterViewInit(): void {
    if (isPlatformBrowser(this.platformId)) {
      this.initMap();
    }
  }

  private initMap(): void {
    // Initialize map centered on Cape Town
    this.map = L.map('map').setView([-33.9249, 18.4241], 13);

    // Add OpenStreetMap tiles
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '© OpenStreetMap contributors'
    }).addTo(this.map);

    // Click event to select location
    this.map.on('click', (e: L.LeafletMouseEvent) => {
      this.setLocation(e.latlng);
    });
  }

  searchAddress(event: Event) {
    const searchStr = (event.target as HTMLInputElement).value;
    if (searchStr.length < 3) return;
    this.searchSubject.next(searchStr);
  }

  private performSearch(searchStr: string) {
    this.leafletNominatimService.searchLocation(searchStr)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (res) => {
          const feature = res.features?.[0];
          if (!feature) return;
          this.selectedAddressName =
            feature.properties.name
            || feature.properties.city
            || feature.properties.state
            || feature.properties.country
            || 'Unknown location';
          const latlng = L.latLng(
            feature.geometry.coordinates[1],
            feature.geometry.coordinates[0]
          );
          this.setLocation(latlng);
          this.map.setView(latlng, 14);
        },
        error: (err) => console.error('Error calling geocoding API:', err),
      });
  }

  private setLocation(latlng: L.LatLng) {
    this.selectedLocation = latlng;

    if (this.marker) {
      this.map.removeLayer(this.marker);
    }

    this.marker = L.marker(latlng).addTo(this.map);

    this.leafletNominatimService.reverseGeocode(latlng.lat, latlng.lng)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (res) => {
          const feature = res.features?.[0];
          this.selectedAddressName = feature?.properties?.name
            || feature?.properties?.city
            || feature?.properties?.state
            || feature?.properties?.country
            || 'Unknown location';
        },
        error: (err) => console.error('Reverse geocode error:', err),
      });
  }

  confirmAddress() {
    console.log('confirmAddress:', this.selectedAddressName);
    this.store.dispatch(new saveLocation(this.selectedAddressName));
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();

    if (this.map) {
      this.map.off();
      this.map.remove();
    }
  }
}
