import { Component, inject} from '@angular/core';
import { Store } from '@ngxs/store';
import { CartState } from '../../store/cart/cart.state';
import { Router } from '@angular/router';
import { ConfirmCart } from '../../store/cart/cart.actions';

@Component({
  selector: 'app-confirmed-cart',
  imports: [],
  templateUrl: './confirmed-cart.component.html',
  styleUrl: './confirmed-cart.component.scss'
})
export class ConfirmedCartComponent {

  private store = inject(Store)
  selectedCart$ = this.store.selectSnapshot( CartState.getAllCartItems)

  constructor(
    private router: Router
  ){}

  updateCart(){
    this.store.dispatch(new ConfirmCart(false))
    this.router.navigateByUrl('/products')

  }

}
