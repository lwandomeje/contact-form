import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfirmedCartComponent } from './confirmed-cart.component';

describe('ConfirmedCartComponent', () => {
  let component: ConfirmedCartComponent;
  let fixture: ComponentFixture<ConfirmedCartComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ConfirmedCartComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ConfirmedCartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
