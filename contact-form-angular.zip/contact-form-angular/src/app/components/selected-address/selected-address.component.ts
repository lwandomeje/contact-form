import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DeliveryAddressState } from '../../store/deliveryAddress/deliveryAddress.state';
import { Store } from '@ngxs/store';
import { changeUserLocation } from '../../store/deliveryAddress/delivery.actions';

@Component({
  selector: 'app-selected-address',
  imports: [CommonModule],
  templateUrl: './selected-address.component.html',
  styleUrl: './selected-address.component.scss'
})
export class SelectedAddressComponent {
  private store = inject(Store)
  selectedAddress$ = this.store.select( DeliveryAddressState.getdeviveryAddress)

  changeLocation(){
    this.store.dispatch( new changeUserLocation() )
  }
}
