import { Component, inject } from '@angular/core';
import { MAT_BOTTOM_SHEET_DATA, MatBottomSheetRef } from '@angular/material/bottom-sheet';
import { Store } from '@ngxs/store';
import { Logout } from '../../../store/auth/auth.actions';
import { Router } from '@angular/router';


@Component({
  selector: 'app-reset-password-sheet',
  imports: [],
  templateUrl: './reset-password-sheet.component.html',
  styleUrl: './reset-password-sheet.component.scss'
})
export class ResetPasswordSheetComponent {

  data = inject(MAT_BOTTOM_SHEET_DATA)
  private bottomSheetRef = inject(MatBottomSheetRef<ResetPasswordSheetComponent>)
  private store = inject(Store)
  
  constructor(
    private router : Router
  ){}

  close(){
    this.bottomSheetRef.dismiss();
    this.store.dispatch( new Logout())
  }

  success(){
    this.bottomSheetRef.dismiss();
    this.store.dispatch( new Logout())
    this.router.navigateByUrl('')
  }
  
}
