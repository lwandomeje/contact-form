import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ResetPasswordSheetComponent } from './reset-password-sheet.component';

describe('ResetPasswordSheetComponent', () => {
  let component: ResetPasswordSheetComponent;
  let fixture: ComponentFixture<ResetPasswordSheetComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ResetPasswordSheetComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ResetPasswordSheetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
