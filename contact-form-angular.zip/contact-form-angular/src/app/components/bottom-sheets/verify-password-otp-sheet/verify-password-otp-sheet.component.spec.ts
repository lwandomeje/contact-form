import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VerifyPasswordOtpSheetComponent } from './verify-password-otp-sheet.component';

describe('VerifyPasswordOtpSheetComponent', () => {
  let component: VerifyPasswordOtpSheetComponent;
  let fixture: ComponentFixture<VerifyPasswordOtpSheetComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [VerifyPasswordOtpSheetComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(VerifyPasswordOtpSheetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
