import { Component, inject } from '@angular/core';
import { MAT_BOTTOM_SHEET_DATA } from '@angular/material/bottom-sheet';
import { MatBottomSheetRef } from '@angular/material/bottom-sheet';
import { Store } from '@ngxs/store';
import { Logout } from '../../../store/auth/auth.actions';
import { Router } from '@angular/router';

@Component({
  selector: 'app-verify-password-otp-sheet',
  imports: [],
  templateUrl: './verify-password-otp-sheet.component.html',
  styleUrl: './verify-password-otp-sheet.component.scss'
})
export class VerifyPasswordOtpSheetComponent {

  data = inject(MAT_BOTTOM_SHEET_DATA);
  private bottomSheetRef = inject(MatBottomSheetRef<VerifyPasswordOtpSheetComponent>);
  private store = inject(Store)

  constructor(
    private router: Router
  ) { }  

  close(){
    this.bottomSheetRef.dismiss();
    this.store.dispatch( new Logout)
  }

  success(){
    this.bottomSheetRef.dismiss();
    this.router.navigateByUrl('/reset-password')

  }

}
