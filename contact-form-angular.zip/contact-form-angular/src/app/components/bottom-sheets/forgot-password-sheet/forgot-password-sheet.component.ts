import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MAT_BOTTOM_SHEET_DATA, MatBottomSheetRef } from '@angular/material/bottom-sheet';
import { Store } from '@ngxs/store';
import { Logout } from '../../../store/auth/auth.actions';
import { Router } from '@angular/router';


@Component({
  selector: 'app-forgot-password-sheet',
  imports: [CommonModule],
  templateUrl: './forgot-password-sheet.component.html',
  styleUrl: './forgot-password-sheet.component.scss'
})
export class ForgotPasswordSheetComponent {
  
  data = inject(MAT_BOTTOM_SHEET_DATA);
  private bottomSheetRef = inject(MatBottomSheetRef<ForgotPasswordSheetComponent>)
  private store = inject(Store)

  constructor(
    private router : Router
  ){}

  closeSheet(): void {
    this.bottomSheetRef.dismiss();
    this.store.dispatch( new Logout())
  }

  goToVerify(): void{
    this.bottomSheetRef.dismiss();
    this.router.navigateByUrl('/verify-opt')
  }
}
