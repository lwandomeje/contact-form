import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ForgotPasswordSheetComponent } from './forgot-password-sheet.component';

describe('ForgotPasswordSheetComponent', () => {
  let component: ForgotPasswordSheetComponent;
  let fixture: ComponentFixture<ForgotPasswordSheetComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ForgotPasswordSheetComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ForgotPasswordSheetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
