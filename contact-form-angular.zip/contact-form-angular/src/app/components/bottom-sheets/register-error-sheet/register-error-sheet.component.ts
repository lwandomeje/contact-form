import { Component, inject } from '@angular/core';
import { MAT_BOTTOM_SHEET_DATA, MatBottomSheetRef } from '@angular/material/bottom-sheet';
import { Store } from '@ngxs/store';
import { Logout } from '../../../store/auth/auth.actions';
import { Router } from '@angular/router';


@Component({
  selector: 'app-register-error-sheet',
  imports: [],
  templateUrl: './register-error-sheet.component.html',
  styleUrl: './register-error-sheet.component.scss'
})
export class RegisterErrorSheetComponent {

  data = inject(MAT_BOTTOM_SHEET_DATA);
  private bottomSheetRef = inject(MatBottomSheetRef<RegisterErrorSheetComponent>)
  private store = inject(Store)
  
  constructor(
    private router : Router
  ){}

  closeSheet(): void {
    this.bottomSheetRef.dismiss();
    this.store.dispatch( new Logout())
  }

  success(): void {
    this.bottomSheetRef.dismiss();
    this.store.dispatch( new Logout())
    this.router.navigateByUrl('')

  }


}
