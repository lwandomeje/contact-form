import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RegisterErrorSheetComponent } from './register-error-sheet.component';

describe('RegisterErrorSheetComponent', () => {
  let component: RegisterErrorSheetComponent;
  let fixture: ComponentFixture<RegisterErrorSheetComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RegisterErrorSheetComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RegisterErrorSheetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
