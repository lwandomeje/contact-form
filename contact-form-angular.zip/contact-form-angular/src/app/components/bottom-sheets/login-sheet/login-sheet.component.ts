import { Component, inject } from '@angular/core';
import { MAT_BOTTOM_SHEET_DATA, MatBottomSheetRef } from '@angular/material/bottom-sheet';
import { Store } from '@ngxs/store';
import { Logout } from '../../../store/auth/auth.actions';

@Component({
  selector: 'app-login-sheet',
  imports: [],
  templateUrl: './login-sheet.component.html',
  styleUrl: './login-sheet.component.scss'
})
export class LoginSheetComponent {

  data = inject(MAT_BOTTOM_SHEET_DATA);
  private bottomSheetRef = inject(MatBottomSheetRef<LoginSheetComponent>)
  private store = inject(Store)

  closeSheet(): void {
    this.bottomSheetRef.dismiss();
    this.store.dispatch( new Logout())
  }
  
}
