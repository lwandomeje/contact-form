import { Component, Input, Output, EventEmitter, inject } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { Dessert } from '../../inetrfaces/desserts.interface';
import { CommonModule } from '@angular/common'
import { Store } from '@ngxs/store';
import { distinctUntilChanged, map, take} from 'rxjs';
import { CartState } from '../../store/cart/cart.state';

@Component({
  selector: 'app-product-card',
  imports: [MatButtonModule, CommonModule],
  templateUrl: './product-card.component.html',
  styleUrl: './product-card.component.scss'
})
export class ProductCardComponent {
  private store = inject(Store);
  @Input() dessert!: Dessert;
  @Output() addDessert = new EventEmitter<Dessert>();
  @Output() dessertCountIncrement = new EventEmitter<{quantity:number, dessert:Dessert}>();
  @Output() dessertCountDecrement = new EventEmitter<{quantity:number, dessert:Dessert}>();

  isInCart$ = this.store.select(CartState.isInCart)
    .pipe(
      map(selectorFn => selectorFn(this.dessert.productId)),
      distinctUntilChanged(),
    )
    
  quantity$ = this.store.select(CartState.dessertCount)
  .pipe(
    map(selectorFn => selectorFn(this.dessert.productId)),
    distinctUntilChanged(),
  )

 addToCart(){
    this.addDessert.emit(this.dessert)
  }

  increment(){
    this.quantity$.pipe(take(1)).subscribe(quantity => {
      this.dessertCountIncrement.emit({
        quantity,
        dessert: this.dessert
      })
    })
  }

  decrement() {
    this.quantity$.pipe(take(1)).subscribe(quantity => {
      this.dessertCountDecrement.emit({
        quantity,
        dessert: this.dessert
      });
    });
  }


}
