import { Component, inject} from '@angular/core';
import { CommonModule } from '@angular/common';
import { CartItemComponent } from '../cart-items/cart-item.component';
import { Store } from '@ngxs/store';
import { CartState } from '../../store/cart/cart.state';
import { Dessert } from '../../inetrfaces/desserts.interface';
import { ConfirmCart, RemoveDessertFomCart } from '../../store/cart/cart.actions';
import { Router } from '@angular/router';


@Component({
  selector: 'app-cart',
  imports: [CartItemComponent, CommonModule],
  templateUrl: './cart.component.html',
  styleUrl: './cart.component.scss'
})
export class CartComponent {
  private store = inject(Store)
  cartItems$ = this.store.select(CartState.getAllCartItems)
  totaCartPrice$ = this.store.select(CartState.getTotalCartPrice)
  numberOfCartItems$ = this.store.select(CartState.getNumberOfCartItems)

  constructor( 
    private readonly route: Router
  ){ }

  removeFromCart(dessert:Dessert){
    this.store.dispatch(new RemoveDessertFomCart(dessert))
  }

  conform(){
    this.store.dispatch( new ConfirmCart(true))
    this.route.navigateByUrl('/check-out')

  }

}


  